package com.example.pricer

import android.net.Uri
import android.os.Bundle
import android.util.Log // Ensure Log is imported
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect // Import LaunchedEffect if needed
import androidx.compose.runtime.getValue // Import getValue delegate
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pricer.data.model.* // Import needed models and enums
import com.example.pricer.ui.dialogs.* // Import ALL your dialog composables
import com.example.pricer.ui.screens.CatalogScreen
import com.example.pricer.ui.screens.QuotePreviewScreen
import com.example.pricer.ui.theme.PricerTheme // Import your app theme
import com.example.pricer.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    // Instantiate the ViewModel using the activity-ktx delegate
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            // Apply the application theme
            PricerTheme {
                // Get the current context
                val context = LocalContext.current

                // --- State Observation ---
                // Observe the current UI mode (Catalog or Quote Preview)
                val uiMode by viewModel.uiMode.collectAsStateWithLifecycle()
                // Observe which dialog should be currently shown
                val currentDialog by viewModel.currentDialog.collectAsStateWithLifecycle()

                // --- Activity Result Launchers ---

                // Launcher for saving the PDF using the OpenDocumentTree contract
                // This asks the user to pick a FOLDER (directory)
                val requestDirectoryLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocumentTree(),
                    onResult = { dirUri: Uri? ->
                        if (dirUri != null) {
                            Log.d("MainActivity", "Directory selected: $dirUri")
                            // Get the current quote data from the ViewModel
                            val quote = viewModel.currentQuote.value
                            if (quote == null) {
                                Log.e("MainActivity", "PDF Generation Error: Quote data is null.")
                                Toast.makeText(context, "Cannot generate PDF: Quote data missing.", Toast.LENGTH_LONG).show()
                                return@rememberLauncherForActivityResult
                            }
                            if (quote.customerName.isBlank()){
                                Log.e("MainActivity", "PDF Generation Error: Customer name is blank.")
                                Toast.makeText(context, "Please set a customer name before generating PDF.", Toast.LENGTH_LONG).show()
                                // Optionally re-open the customer name dialog
                                // viewModel.showDialog(DialogState.CUSTOMER_NAME)
                                return@rememberLauncherForActivityResult
                            }


                            // --- Generate a filename ---
                            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                            // Sanitize customer name for filename (replace non-alphanumeric with underscore)
                            val safeCustomerName = quote.customerName.replace(Regex("[^A-Za-z0-9]"), "_").take(30) // Limit length
                            val fileName = "Quote_${safeCustomerName}_$timestamp.pdf"

                            // --- Call the ViewModel to handle PDF creation and writing ---
                            // Use the generatePdfToUri function which should handle DocumentFile API
                            val success = viewModel.generatePdfToUri(context, quote, dirUri, fileName)

                            // Show feedback Toast
                            val message = if (success) "PDF saved successfully in selected folder!" else "Failed to generate or save PDF."
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

                        } else {
                            // User cancelled the directory picker
                            Log.d("MainActivity", "Directory selection cancelled.")
                            Toast.makeText(context, "PDF generation cancelled.", Toast.LENGTH_SHORT).show()
                        }
                    }
                )

                // Helper function to launch the directory picker
                fun launchPdfGeneration() {
                    Log.d("MainActivity", "Launching PDF Generation (Requesting Directory)...")
                    // Request the user pick a directory. Pass null as the initial Uri.
                    requestDirectoryLauncher.launch(null)
                }

                // --- Main UI Content Switching ---
                // Display either CatalogScreen or QuotePreviewScreen based on uiMode
                MainContent(
                    uiMode = uiMode,
                    viewModel = viewModel,
                    onNavigateToQuotePreview = { viewModel.showQuotePreview() }, // Let VM handle steps
                    onNavigateBack = { viewModel.showCatalogView() }, // Tell VM to go back
                    onGeneratePdfClick = { launchPdfGeneration() } // Trigger our launcher helper
                )

                // --- Handle Dialog Display ---
                // This composable observes currentDialog state and shows the appropriate dialog
                HandleDialogs(dialogState = currentDialog, viewModel = viewModel)

            } // End PricerTheme
        } // End setContent
    } // End onCreate
} // End MainActivity


/**
 * A simple container composable that switches between the main screens
 * based on the current UI mode.
 */
@Composable
private fun MainContent(
    uiMode: UiMode,
    viewModel: MainViewModel,
    onNavigateToQuotePreview: () -> Unit,
    onNavigateBack: () -> Unit,
    onGeneratePdfClick: () -> Unit
) {
    when (uiMode) {
        UiMode.CATALOG -> CatalogScreen(
            viewModel = viewModel,
            onNavigateToQuotePreview = onNavigateToQuotePreview
        )
        UiMode.QUOTE_PREVIEW -> QuotePreviewScreen(
            viewModel = viewModel,
            onNavigateBack = onNavigateBack,
            onGeneratePdfClick = onGeneratePdfClick
        )
    }
}

/**
 * Composable responsible for observing the current dialog state from the ViewModel
 * and displaying the corresponding Dialog composable. It passes the necessary data
 * and callbacks to each specific dialog.
 */
@Composable
private fun HandleDialogs(dialogState: DialogState, viewModel: MainViewModel) {

    // Collect necessary states that might be needed by different dialogs
    // Using getValue delegate for cleaner access inside the Composable
    val productToEdit by viewModel.productToEdit.collectAsStateWithLifecycle()
    val multiplierToEdit by viewModel.multiplierToEdit.collectAsStateWithLifecycle()
    val productForMultiplier by viewModel.productForMultiplierAssignment.collectAsStateWithLifecycle()
    val currentTaxRate by viewModel.taxRate.collectAsStateWithLifecycle()
    val catalogs by viewModel.catalogs.collectAsStateWithLifecycle()
    val activeCatalog by viewModel.activeCatalog.collectAsStateWithLifecycle() // Use the combined flow
    val assignedMultipliersState by viewModel.selectedMultipliersForAssignment.collectAsStateWithLifecycle() // State for assign dialog
    val companyName by viewModel.quoteCompanyName.collectAsStateWithLifecycle() // For quote details dialog
    val customMessage by viewModel.quoteCustomMessage.collectAsStateWithLifecycle() // For quote details dialog

    // Determine the list of multipliers from the currently active catalog
    val multipliers = activeCatalog?.multipliers ?: emptyList()

    // Decide which dialog to show based on the dialogState Flow value
    when (dialogState) {
        DialogState.NONE -> { /* Do nothing, no dialog is shown */ }

        DialogState.ADD_EDIT_PRODUCT -> {
            AddEditProductDialog(
                productToEdit = productToEdit, // Pass null for Add, Product object for Edit
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { product ->
                    viewModel.addOrUpdateProduct(product)
                    // dismissDialog() is now called inside addOrUpdateProduct
                }
            )
        }

        DialogState.MANAGE_MULTIPLIERS -> {
            ManageMultipliersDialog(
                multipliers = multipliers, // Pass the list from active catalog
                // We don't pass multiplierToEdit here as the Dialog manages its own Add/Edit sub-state now
                onDismiss = { viewModel.dismissDialog() },
                // Updated callbacks based on ManageMultipliersDialog structure
                onAddMultiplier = { newMultiplier -> viewModel.addOrUpdateMultiplier(newMultiplier)},
                onUpdateMultiplier = { updatedMultiplier -> viewModel.addOrUpdateMultiplier(updatedMultiplier)},
                onDeleteMultiplier = { multiplierId -> viewModel.deleteMultiplier(multiplierId)}
            )
        }

        DialogState.ASSIGN_MULTIPLIER -> {
            // Ensure the product context for assignment is not null
            productForMultiplier?.let { product ->
                AssignMultiplierDialog(
                    product = product,
                    availableMultipliers = multipliers, // Pass global multipliers from active catalog
                    initialAssignments = assignedMultipliersState, // Pass initial state for this product
                    onDismiss = { viewModel.dismissDialog() },
                    onConfirm = { finalAssignments -> // Callback provides Map<MultiplierId, OverrideValue?>
                        viewModel.confirmMultiplierAssignment(product.id, finalAssignments)
                        // dismissDialog() called inside confirmMultiplierAssignment
                    }
                )
            } ?: run {
                // Safety check: If productForMultiplier is null, log error and dismiss
                // This might happen if the state updates incorrectly
                if(dialogState == DialogState.ASSIGN_MULTIPLIER) { // Check state again to avoid logging on quick dismissal
                    Log.e("HandleDialogs", "AssignMultiplierDialog requested but product context is missing!")
                    LaunchedEffect(Unit) { // Use LaunchedEffect for state change outside composition
                        viewModel.dismissDialog()
                    }
                }
            }
        }

        DialogState.SET_TAX -> {
            SetTaxDialog(
                initialTaxRate = currentTaxRate, // Pass the current rate from ViewModel state
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { newRate ->
                    viewModel.setTaxRate(newRate)
                    // dismissDialog() called inside setTaxRate
                }
            )
        }

        DialogState.MANAGE_CATALOGS -> {
            ManageCatalogsDialog(
                catalogs = catalogs,
                activeCatalogId = activeCatalog?.id ?: "", // Pass the active ID (handle null case)
                onDismiss = { viewModel.dismissDialog() },
                onSelectCatalog = { catalogId -> viewModel.loadCatalog(catalogId) }, // Let VM handle switching
                onAddCatalog = { name -> viewModel.createCatalog(name) },
                onRenameCatalog = { id, newName -> viewModel.renameCatalog(id, newName) },
                onDeleteCatalog = { id -> viewModel.deleteCatalog(id) }
                // Dismissal usually handled by onSelectCatalog or explicit Close button inside the dialog
            )
        }

        DialogState.CUSTOMER_NAME -> {
            CustomerNameDialog(
                // Pass initial name if needed later: initialCustomerName = viewModel.quoteCustomerName.value
                onDismiss = {
                    viewModel.dismissDialog()
                    // If dismissing, user cancelled quote preview intent, so stay/go back to catalog
                    viewModel.showCatalogView()
                },
                onConfirm = { name ->
                    // ViewModel handles saving name and switching mode
                    viewModel.proceedToQuotePreview(name)
                    // dismissDialog is called inside proceedToQuotePreview
                }
            )
        }

        DialogState.QUOTE_DETAILS -> {
            QuoteDetailsDialog(
                initialCompanyName = companyName, // Pass state collected above
                initialCustomMessage = customMessage, // Pass state collected above
                onDismiss = { viewModel.dismissDialog() },
                onConfirm = { newCompanyName, newCustomMessage ->
                    viewModel.updateQuoteDetails(newCompanyName, newCustomMessage)
                    // dismissDialog is called inside updateQuoteDetails
                }
            )
        }
    } // End when
} // End HandleDialogs