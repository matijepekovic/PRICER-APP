package com.example.pricer.data.model

import kotlinx.serialization.Serializable // Make sure you have the serialization dependency added in build.gradle.kts
import java.util.UUID

// Represents a single product in the catalog
@Serializable
data class Product(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "", // Made vars temporarily if needed for direct editing in some dialog implementations, review later
    var description: String = "",
    var unitType: String = "unit",
    var basePrice: Double = 0.0,
    var category: String = "Default" // For sorting/filtering
)

// Defines the types of multipliers available
@Serializable
enum class MultiplierType {
    PERCENTAGE, // Applied as a percentage of the base price
    FIXED_PER_UNIT // Applied as a fixed amount per unit
}

// Represents a global multiplier definition (e.g., "Discount", "Material Surcharge")
@Serializable
data class Multiplier(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var type: MultiplierType = MultiplierType.PERCENTAGE,
    var value: Double = 0.0 // The percentage value (e.g., 10.0 for 10%) or the fixed amount
)

// Represents a multiplier *as it is applied* to a specific quote item.
// This allows for potential overrides of the global multiplier value for that specific item.
@Serializable
data class AppliedMultiplier(
    val multiplierId: String,        // Links back to the global Multiplier definition
    val name: String,                // Copied name for display convenience in the quote
    val type: MultiplierType,        // Copied type for calculation convenience
    val appliedValue: Double         // The actual value used (global value OR an overridden value)
)

// Enum to define the criteria for sorting products in the catalog view
enum class ProductSortCriteria {
    NAME_ASC, NAME_DESC,
    PRICE_ASC, PRICE_DESC,
    CATEGORY_ASC, CATEGORY_DESC
}

// Enum to represent the different main UI states (screens)
enum class UiMode {
    CATALOG,
    QUOTE_PREVIEW
}

// Enum to manage which dialog is currently open (if any)
enum class DialogState {
    NONE, // No dialog is open
    ADD_EDIT_PRODUCT,
    MANAGE_MULTIPLIERS,
    ASSIGN_MULTIPLIER,
    SET_TAX,
    MANAGE_CATALOGS,
    CUSTOMER_NAME,
    QUOTE_DETAILS
}