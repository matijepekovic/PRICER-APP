package com.example.pricer.ui.theme

import androidx.compose.ui.graphics.Color

// These are the standard Material 3 baseline colors.
// You can customize these hex values to match your desired branding.

// Light Theme Colors
val Purple40 = Color(0xFF6650a4)         // Primary
val PurpleGrey40 = Color(0xFF625b71)    // Secondary
val Pink40 = Color(0xFF7D5260)           // Tertiary
val Error40 = Color(0xFFB3261E)          // Error
val BackgroundLight = Color(0xFFFFFBFE)  // Background
val SurfaceLight = Color(0xFFFFFBFE)     // Surface (Cards, Sheets, Menus)
val OnPrimaryLight = Color(0xFFFFFFFF)   // Text/Icons on Primary
val OnSecondaryLight = Color(0xFFFFFFFF) // Text/Icons on Secondary
val OnTertiaryLight = Color(0xFFFFFFFF)  // Text/Icons on Tertiary
val OnErrorLight = Color(0xFFFFFFFF)     // Text/Icons on Error
val OnBackgroundLight = Color(0xFF1C1B1F) // Text/Icons on Background
val OnSurfaceLight = Color(0xFF1C1B1F)    // Text/Icons on Surface
val OnSurfaceVariantLight = Color(0xFF49454F) // Subtle Text/Icons on Surface
val OutlineLight = Color(0xFF79747E)     // Outlines, Dividers

// Dark Theme Colors
val Purple80 = Color(0xFFD0BCFF)         // Primary
val PurpleGrey80 = Color(0xFFCCC2DC)    // Secondary
val Pink80 = Color(0xFFEFB8C8)           // Tertiary
val Error80 = Color(0xFFF2B8B5)          // Error
val BackgroundDark = Color(0xFF1C1B1F)   // Background
val SurfaceDark = Color(0xFF1C1B1F)      // Surface
val OnPrimaryDark = Color(0xFF371E73)    // Text/Icons on Primary
val OnSecondaryDark = Color(0xFF332D41)  // Text/Icons on Secondary
val OnTertiaryDark = Color(0xFF482532)   // Text/Icons on Tertiary
val OnErrorDark = Color(0xFF601410)      // Text/Icons on Error
val OnBackgroundDark = Color(0xFFE6E1E5)  // Text/Icons on Background
val OnSurfaceDark = Color(0xFFE6E1E5)     // Text/Icons on Surface
val OnSurfaceVariantDark = Color(0xFFCAC4D0) // Subtle Text/Icons on Surface
val OutlineDark = Color(0xFF938F99)      // Outlines, Dividers


// You can add custom semantic colors if needed:
// val SuccessGreen = Color(0xFF4CAF50)
// val WarningOrange = Color(0xFFFF980