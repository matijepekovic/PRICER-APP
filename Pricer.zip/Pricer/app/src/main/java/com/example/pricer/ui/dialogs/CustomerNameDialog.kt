package com.example.pricer.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

/**
 * A simple dialog to prompt the user for the customer's name before generating a quote preview.
 *
 * @param onDismiss Lambda invoked when the dialog is dismissed (e.g., Cancel or clicking outside).
 *                  The caller (ViewModel/Activity) should handle the logic for cancellation
 *                  (e.g., returning to the catalog view).
 * @param onConfirm Lambda invoked when the Confirm button is clicked. Passes the entered customer name.
 *                  The name is validated to be non-blank before invoking.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerNameDialog(
    // Optional: Pass initial value if you allow re-editing name from preview later
    // initialCustomerName: String = "",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit // Passes the non-blank customer name
) {
    var customerName by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) } // Basic error state
    val focusManager = LocalFocusManager.current

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = MaterialTheme.shapes.large) {
            Column(modifier = Modifier.padding(16.dp)) {
                // --- Title ---
                Text("Enter Customer Name", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 16.dp))

                // --- Input Field ---
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it; nameError = false }, // Clear error on typing
                    label = { Text("Customer Name*") },
                    modifier = Modifier.fillMaxWidth(),
                    isError = nameError, // Highlight field if error occurred on confirm attempt
                    supportingText = if(nameError) { { Text("Customer name cannot be empty") } } else null,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words, // Capitalize names
                        imeAction = ImeAction.Done // Use Done action
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            // Try confirming when keyboard Done is pressed
                            if (customerName.isNotBlank()) {
                                onConfirm(customerName.trim())
                            } else {
                                nameError = true // Show error if blank on Done press
                            }
                        }
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))

                // --- Action Buttons ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (customerName.isNotBlank()) {
                                // Valid name, call confirm callback
                                onConfirm(customerName.trim())
                            } else {
                                // Blank name, show error and keep dialog open
                                nameError = true
                            }
                        },
                        // Enable confirm button only if text is not blank? Or allow attempt?
                        // enabled = customerName.isNotBlank()
                    ) {
                        Text("Confirm")
                    }
                } // End Button Row
            } // End Column
        } // End Card
    } // End Dialog
}