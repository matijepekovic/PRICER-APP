package com.example.pricer.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.* // Checkbox, Indeterminate Checkbox
import androidx.compose.material.icons.outlined.Info // Info icon
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.pricer.data.model.Multiplier
import com.example.pricer.data.model.MultiplierType
import com.example.pricer.data.model.Product
import com.example.pricer.util.formatCurrency
import com.example.pricer.util.formatPercentage
import androidx.compose.ui.text.style.TextAlign
/**
 * Dialog for assigning global multipliers to a specific product and allowing value overrides.
 *
 * @param product The product to which multipliers are being assigned.
 * @param availableMultipliers The list of all global multipliers defined in the catalog.
 * @param initialAssignments The currently active assignments for this product (Map<MultiplierId, OverrideValue?>).
 * @param onDismiss Lambda to dismiss the dialog.
 * @param onConfirm Lambda called when confirming assignments. Passes the updated assignment map (Map<MultiplierId, OverrideValue?>).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignMultiplierDialog(
    product: Product,
    availableMultipliers: List<Multiplier>,
    initialAssignments: Map<String, Double?>, // Map<MultiplierId, OverrideValue?>
    onDismiss: () -> Unit,
    onConfirm: (Map<String, Double?>) -> Unit // Returns the final selections/overrides for this product
) {
    // --- State Management within the Dialog ---
    // Mutable map to track selections and overrides within the dialog session.
    // Initialize it with the assignments passed in from the ViewModel.
    val currentAssignments = remember { mutableStateMapOf<String, Double?>().apply { putAll(initialAssignments) } }

    // --- Dialog UI ---
    Dialog(onDismissRequest = onDismiss) {
        Card(shape = MaterialTheme.shapes.large) {
            Column(modifier = Modifier.padding(16.dp)) {
                // --- Title ---
                Text(
                    text = "Assign Multipliers for:",
                    style = MaterialTheme.typography.labelMedium // Smaller label above product name
                )
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // --- Handle No Multipliers Defined ---
                if (availableMultipliers.isEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(8.dp))
                        Text("No global multipliers have been defined yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(16.dp)) // Space before buttons
                }
                // --- Multiplier List ---
                else {
                    Text("Available Multipliers:", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 350.dp)) { // Constrain height
                        items(items = availableMultipliers, key = { it.id }) { multiplier ->
                            // State for the override input field specific to this multiplier row
                            var overrideValueString by remember(multiplier.id) {
                                mutableStateOf(
                                    currentAssignments[multiplier.id]?.toString() ?: ""
                                )
                            }
                            // Derived state: is this multiplier currently selected?
                            val isSelected = currentAssignments.containsKey(multiplier.id)

                            AssignMultiplierRow(
                                multiplier = multiplier,
                                isSelected = isSelected,
                                overrideValueString = overrideValueString,
                                onSelectionChange = { selected ->
                                    if (selected) {
                                        // Add to map, initially with null override (use default)
                                        currentAssignments[multiplier.id] = null
                                        overrideValueString = "" // Clear override field when selecting
                                    } else {
                                        // Remove from map
                                        currentAssignments.remove(multiplier.id)
                                        overrideValueString = "" // Clear override field
                                    }
                                },
                                onOverrideValueChange = { newValueString ->
                                    // Update local string state
                                    overrideValueString = newValueString
                                    // Attempt to parse and update the assignment map only if selected
                                    if(isSelected) {
                                        val parsedValue = newValueString.toDoubleOrNull()
                                        currentAssignments[multiplier.id] = parsedValue // Store null if unparsable or empty, indicating override reset/error? Or keep default? Let's store null.
                                        // Or: currentAssignments[multiplier.id] = if (newValueString.isBlank()) null else parsedValue // Treat blank as reset to default
                                    }

                                }
                            )
                            Divider()
                        } // End items loop
                    } // End LazyColumn
                    Spacer(modifier = Modifier.height(16.dp)) // Space before buttons
                }

                // --- Action Buttons ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        // Pass the final state of the internal assignment map back to ViewModel
                        onConfirm(currentAssignments.toMap()) // Convert mutable map state to immutable map
                    }) {
                        Text("Confirm")
                    }
                } // End Button Row
            } // End Column
        } // End Card
    } // End Dialog
}


// --- Helper Composable for a single row in the assignment list ---
@Composable
private fun AssignMultiplierRow(
    multiplier: Multiplier,
    isSelected: Boolean,
    overrideValueString: String,
    onSelectionChange: (Boolean) -> Unit,
    onOverrideValueChange: (String) -> Unit
) {
    val focusManager = LocalFocusManager.current
    val overrideParseResult = overrideValueString.toDoubleOrNull()
    val hasValidOverride = overrideParseResult != null && overrideValueString.isNotBlank() // Non-blank and parsable
    // Use indeterminate checkbox if selected but override is invalid/empty
    val checkboxState = when {
        !isSelected -> androidx.compose.ui.state.ToggleableState.Off
        !overrideValueString.isBlank() && overrideParseResult == null -> androidx.compose.ui.state.ToggleableState.Indeterminate // Selected but invalid override
        else -> androidx.compose.ui.state.ToggleableState.On // Off or On (selected with valid/no override)
    }


    Row(
        modifier = Modifier
            .fillMaxWidth()
            // Make row clickable to toggle selection
            .clickable { onSelectionChange(!isSelected) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // --- Checkbox ---
        TriStateCheckbox(
            state = checkboxState,
            onClick = { onSelectionChange(!isSelected) }
        )
        Spacer(Modifier.width(8.dp))

        // --- Multiplier Name and Default Value ---
        Column(modifier = Modifier.weight(1f)) {
            Text(multiplier.name, style = MaterialTheme.typography.bodyLarge)
            val valueText = when (multiplier.type) {
                MultiplierType.PERCENTAGE -> formatPercentage(multiplier.value)
                MultiplierType.FIXED_PER_UNIT -> formatCurrency(multiplier.value)
            }
            Text(
                "Default: $valueText",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(8.dp))

        // --- Override Value Input (Enabled only if selected) ---
        OutlinedTextField(
            value = overrideValueString,
            onValueChange = onOverrideValueChange,
            label = { Text("Override") },
            enabled = isSelected, // Only allow input if multiplier is selected
            isError = !overrideValueString.isBlank() && overrideParseResult == null, // Error if non-blank but not parsable
            modifier = Modifier.width(110.dp), // Constrained width for override
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Decimal,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
            leadingIcon = if (multiplier.type == MultiplierType.FIXED_PER_UNIT) ({ Text("$") }) else null,
            trailingIcon = if (multiplier.type == MultiplierType.PERCENTAGE) ({ Text("%") }) else null,
            singleLine = true,
            textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.End)
            // Use supportingText for validation messages if needed
            // supportingText = { if (!overrideValueString.isBlank() && overrideParseResult == null) Text("Invalid") }
        )
    }
}