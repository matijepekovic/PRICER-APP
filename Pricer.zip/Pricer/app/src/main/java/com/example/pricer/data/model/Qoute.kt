package com.example.pricer.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

// Represents a single line item within a Quote.
@Serializable
data class QuoteItem(
    // Unique identifier for this specific line item *within the quote*
    val id: String = UUID.randomUUID().toString(),

    // A *snapshot* of the product details at the time the quote was generated or item added.
    // This prevents the quote from changing if the master product in the catalog is edited later.
    val product: Product,

    // The quantity of the product requested for this line item.
    var quantity: Int, // Use Int here; validation happens before creating the QuoteItem

    // The list of multipliers specifically applied to this line item,
    // including their *actual applied values* (which might be overrides).
    val appliedMultipliers: List<AppliedMultiplier> = emptyList()
) {
    // Calculated property: Base cost before multipliers (Unit Price * Quantity)
    val baseTotal: Double
        get() = product.basePrice * quantity

    // Calculated property: Total adjustment amount from all applied multipliers
    val multiplierAdjustment: Double
        get() = appliedMultipliers.sumOf { multiplier ->
            when (multiplier.type) {
                // Percentage calculation: (Base Unit Price * (Percentage / 100)) * Quantity
                MultiplierType.PERCENTAGE -> (product.basePrice * (multiplier.appliedValue / 100.0)) * quantity
                // Fixed amount calculation: Fixed Amount * Quantity
                MultiplierType.FIXED_PER_UNIT -> multiplier.appliedValue * quantity
            }
        }

    // Calculated property: Final total for this line item (Base + Multiplier Adjustments)
    val lineTotal: Double
        get() = baseTotal + multiplierAdjustment
}

// Represents the complete Quote document.
@Serializable
data class Quote(
    // Unique identifier for this specific quote instance
    val id: String = UUID.randomUUID().toString(),

    // Name of the customer the quote is for (requested by user)
    var customerName: String = "",

    // Optional: Name of the company generating the quote (requested by user)
    var companyName: String = "",

    // Optional: A personalized message added to the quote (requested by user)
    var customMessage: String = "",

    // The list of all line items included in this quote
    val items: List<QuoteItem> = emptyList(),

    // The tax rate (as a percentage, e.g., 5.0 for 5%) applied to the quote subtotal
    val taxRate: Double = 0.0
) {
    // Calculated property: Sum of all line item totals before tax
    val subtotal: Double
        get() = items.sumOf { it.lineTotal }

    // Calculated property: Amount of tax to be added (Subtotal * (Tax Rate / 100))
    val taxAmount: Double
        get() = subtotal * (taxRate / 100.0)

    // Calculated property: Final total amount for the quote (Subtotal + Tax Amount)
    val grandTotal: Double
        get() = subtotal + taxAmount
}