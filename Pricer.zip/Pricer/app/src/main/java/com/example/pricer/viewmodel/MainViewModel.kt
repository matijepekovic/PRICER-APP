package com.example.pricer.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pricer.data.model.* // Import all data models and enums
import com.example.pricer.util.PdfGenerator // Import PDF utility
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.*
import android.graphics.pdf.PdfDocument
// TODO: Implement actual file persistence (saving/loading catalogs) using Kotlinx Serialization
// import kotlinx.serialization.encodeToString
// import kotlinx.serialization.json.Json
// import java.io.File

class MainViewModel : ViewModel() {

    private companion object {
        const val TAG = "MainViewModel"
        const val DEFAULT_CATALOG_ID = "default_catalog_001"
    }

    // --- Core UI State ---

    // Controls whether the Catalog or Quote Preview screen is shown
    private val _uiMode = MutableStateFlow(UiMode.CATALOG)
    val uiMode: StateFlow<UiMode> = _uiMode.asStateFlow()

    // Controls which dialog (if any) is currently displayed
    private val _currentDialog = MutableStateFlow(DialogState.NONE)
    val currentDialog: StateFlow<DialogState> = _currentDialog.asStateFlow()

    // --- Catalog Data State ---

    // Holds all available catalogs, mapped by their unique ID.
    // Starts with one default empty catalog.
    private val _catalogs = MutableStateFlow<Map<String, Catalog>>(
        mapOf(DEFAULT_CATALOG_ID to Catalog(id = DEFAULT_CATALOG_ID, name = "Default Catalog"))
    )
    val catalogs: StateFlow<Map<String, Catalog>> = _catalogs.asStateFlow() // Expose available catalogs map

    // ID of the currently active catalog being viewed/edited
    private val _activeCatalogId = MutableStateFlow(DEFAULT_CATALOG_ID)
    // val activeCatalogId: StateFlow<String> = _activeCatalogId // Expose if needed elsewhere

    // Provides the full Catalog object for the currently active ID.
    // Automatically updates when _activeCatalogId or _catalogs changes.
    val activeCatalog: StateFlow<Catalog?> = combine(_catalogs, _activeCatalogId) { catalogsMap, activeId ->
        catalogsMap[activeId]
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000), // Keep state for 5s after last subscriber stops
        initialValue = _catalogs.value[_activeCatalogId.value] // Initial value based on default
    )

    // State for product sorting criteria
    private val _productSortCriteria = MutableStateFlow(ProductSortCriteria.NAME_ASC)
    val productSortCriteria: StateFlow<ProductSortCriteria> = _productSortCriteria.asStateFlow()

    // Provides the list of products from the *active* catalog, sorted according to the current criteria.
    val sortedProducts: StateFlow<List<Product>> = combine(
        activeCatalog, // Depends on the currently active catalog
        _productSortCriteria // Depends on the chosen sort order
    ) { catalog, sortCriteria ->
        // If catalog is null (shouldn't happen normally) or has no products, return empty list.
        // Otherwise, sort the products based on criteria.
        catalog?.products?.let { sortProducts(it, sortCriteria) } ?: emptyList()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList() // Start with empty list until first emission
    )

    // Helper function to perform the actual sorting logic
    private fun sortProducts(products: List<Product>, criteria: ProductSortCriteria): List<Product> {
        Log.d(TAG, "Sorting products by: $criteria")
        return when (criteria) {
            ProductSortCriteria.NAME_ASC -> products.sortedBy { it.name.lowercase() } // Case-insensitive sort
            ProductSortCriteria.NAME_DESC -> products.sortedByDescending { it.name.lowercase() }
            ProductSortCriteria.PRICE_ASC -> products.sortedBy { it.basePrice }
            ProductSortCriteria.PRICE_DESC -> products.sortedByDescending { it.basePrice }
            ProductSortCriteria.CATEGORY_ASC -> products.sortedBy { it.category.lowercase() }
            ProductSortCriteria.CATEGORY_DESC -> products.sortedByDescending { it.category.lowercase() }
        }
    }

    // --- Quote Building State ---

    // Temporary storage for quantities entered in the Catalog screen (ProductId -> Quantity as String)
    private val _itemQuantities = MutableStateFlow<Map<String, String>>(emptyMap())
    val itemQuantities: StateFlow<Map<String, String>> = _itemQuantities.asStateFlow()

    // Holds multiplier assignments specific to products (ProductId -> Map<MultiplierId, OverrideValue?>)
    // This state persists across quote building.
    private val _productMultiplierAssignments = MutableStateFlow<Map<String, Map<String, Double?>>>(emptyMap())
    // Public flow not strictly needed if only used internally and via AssignMultiplierDialog state
    val productMultiplierAssignments: StateFlow<Map<String, Map<String, Double?>>> = _productMultiplierAssignments.asStateFlow()
    // The currently generated Quote object, ready for preview or PDF export. Null if no quote built.
    private val _currentQuote = MutableStateFlow<Quote?>(null)
    val currentQuote: StateFlow<Quote?> = _currentQuote.asStateFlow()

    // Current global tax rate (percentage)
    private val _taxRate = MutableStateFlow(0.0)
    val taxRate: StateFlow<Double> = _taxRate.asStateFlow()

    // Temporary states for quote details entered in the dialog
    private val _quoteCompanyName = MutableStateFlow("")
    val quoteCompanyName: StateFlow<String> = _quoteCompanyName.asStateFlow()

    private val _quoteCustomMessage = MutableStateFlow("")
    val quoteCustomMessage: StateFlow<String> = _quoteCustomMessage.asStateFlow()

    private val _quoteCustomerName = MutableStateFlow("") // Needed temporarily for the dialog


    // --- Dialog State ---

    // Holds the product being edited (null if adding new)
    private val _productToEdit = MutableStateFlow<Product?>(null)
    val productToEdit: StateFlow<Product?> = _productToEdit.asStateFlow()

    // Holds the multiplier being edited (null if adding new)
    private val _multiplierToEdit = MutableStateFlow<Multiplier?>(null)
    val multiplierToEdit: StateFlow<Multiplier?> = _multiplierToEdit.asStateFlow()

    // Holds the product for which multipliers are being assigned
    private val _productForMultiplierAssignment = MutableStateFlow<Product?>(null)
    val productForMultiplierAssignment: StateFlow<Product?> = _productForMultiplierAssignment.asStateFlow()

    // Holds the state *during* multiplier assignment dialog (MultiplierId -> OverrideValue?)
    private val _selectedMultipliersForAssignment = MutableStateFlow<Map<String, Double?>>(emptyMap())
    val selectedMultipliersForAssignment: StateFlow<Map<String, Double?>> = _selectedMultipliersForAssignment.asStateFlow()


    // --- Initialization ---
    init {
        // TODO: Load saved catalogs from persistent storage on init
        Log.i(TAG, "ViewModel Initialized. Active Catalog ID: ${_activeCatalogId.value}")
        // loadCatalogs() // Example call
    }

    // --- Persistence ---
    // TODO: Implement saveCatalogs() function using Kotlinx Serialization and File I/O
    // private fun saveCatalogs() { viewModelScope.launch { /* ... */ } }
    // TODO: Implement loadCatalogs() function
    // private fun loadCatalogs() { viewModelScope.launch { /* ... */ } }

    // --- UI Mode Control ---
    fun showCatalogView() {
        _uiMode.value = UiMode.CATALOG
        // Clear the quote when returning to catalog? Or keep it for quick re-preview?
        // _currentQuote.value = null // Optional: Reset quote state
        // Reset item quantities? Depends on desired behavior.
        // _itemQuantities.value = emptyMap()
        Log.d(TAG, "Switching to Catalog view")
    }

    fun showQuotePreview() {
        Log.d(TAG, "Attempting to show Quote Preview")
        buildQuote() // Build the quote from current quantities and assignments
        if (_currentQuote.value?.items?.isNotEmpty() == true) {
            // Ask for customer name if not already set on the current quote object
            if(_currentQuote.value?.customerName.isNullOrBlank()) {
                _quoteCustomerName.value = "" // Clear temp state just in case
                showDialog(DialogState.CUSTOMER_NAME)
                Log.d(TAG,"Showing Customer Name dialog before Quote Preview")
            } else {
                // Customer name already exists, proceed directly
                _uiMode.value = UiMode.QUOTE_PREVIEW
                Log.d(TAG, "Switching directly to Quote Preview (Customer name exists)")
            }

        } else {
            Log.w(TAG, "Cannot show Quote Preview: No valid items generated.")
            // TODO: Show feedback to user (e.g., Toast, Snackbar via a separate state flow)
            // Example: _snackbarMessage.value = "Add items with quantities first."
        }
    }

    // Called *after* customer name is entered via dialog
    fun proceedToQuotePreview(customerName: String) {
        _currentQuote.update { it?.copy(customerName = customerName) }
        _uiMode.value = UiMode.QUOTE_PREVIEW
        dismissDialog() // Close the customer name dialog
        Log.d(TAG, "Proceeding to Quote Preview with Customer Name: $customerName")
    }


    // --- Dialog Management ---
    fun showDialog(dialog: DialogState, data: Any? = null) {
        Log.d(TAG, "Showing Dialog: $dialog with data: $data")
        // Prepare specific state based on which dialog is opening
        when (dialog) {
            DialogState.ADD_EDIT_PRODUCT -> _productToEdit.value = data as? Product // Null for Add, Product for Edit
            DialogState.MANAGE_MULTIPLIERS -> {
                // Reset edit state unless specific data is passed (for editing an existing one)
                _multiplierToEdit.value = data as? Multiplier
            }
            DialogState.ASSIGN_MULTIPLIER -> {
                val product = data as? Product
                _productForMultiplierAssignment.value = product
                // Pre-populate dialog state with any *existing* assignments for this product
                val currentAssignments = _productMultiplierAssignments.value[product?.id] ?: emptyMap()
                _selectedMultipliersForAssignment.value = currentAssignments
                Log.d(TAG, "Preparing AssignMultiplierDialog for ${product?.name}. Initial assignments: $currentAssignments")
            }
            DialogState.QUOTE_DETAILS -> {
                // Pre-fill dialog with current quote details
                _quoteCompanyName.value = _currentQuote.value?.companyName ?: ""
                _quoteCustomMessage.value = _currentQuote.value?.customMessage ?: ""
            }
            DialogState.SET_TAX -> {
                // Tax rate is already held in _taxRate, no extra prep needed
            }
            DialogState.CUSTOMER_NAME -> {
                _quoteCustomerName.value = _currentQuote.value?.customerName ?: "" // Pre-fill if editing later?
            }
            DialogState.MANAGE_CATALOGS -> {
                // Catalogs/active ID are already in state, no extra prep needed
            }
            DialogState.NONE -> { /* Should not be called with NONE */ }
        }
        _currentDialog.value = dialog // Set the active dialog
    }

    fun dismissDialog() {
        Log.d(TAG, "Dismissing Dialog: ${_currentDialog.value}")
        // Clear any dialog-specific temporary data when *any* dialog closes
        _productToEdit.value = null
        _multiplierToEdit.value = null
        _productForMultiplierAssignment.value = null
        _selectedMultipliersForAssignment.value = emptyMap() // Reset selection state
        _quoteCustomerName.value = "" // Clear temporary customer name

        // We don't clear _quoteCompanyName or _quoteCustomMessage here,
        // as they are part of the actual Quote object being built/edited.

        _currentDialog.value = DialogState.NONE // Set state back to no dialog
    }

    // --- Product Management ---
    fun addOrUpdateProduct(product: Product) {
        _catalogs.update { currentCatalogs ->
            val activeId = _activeCatalogId.value
            val currentActiveCatalog = currentCatalogs[activeId] ?: run {
                Log.e(TAG, "addOrUpdateProduct failed: Active catalog $activeId not found!")
                return@update currentCatalogs // Return unchanged map if catalog invalid
            }

            val existingProductIndex = currentActiveCatalog.products.indexOfFirst { it.id == product.id }
            val updatedProducts = if (existingProductIndex != -1) {
                // Update: Replace existing product at its index
                Log.d(TAG,"Updating product: ${product.name}")
                currentActiveCatalog.products.toMutableList().apply {
                    this[existingProductIndex] = product
                }
            } else {
                // Add: Append new product to the list
                Log.d(TAG,"Adding new product: ${product.name}")
                currentActiveCatalog.products + product
            }

            // Create updated map entry for the active catalog
            val updatedCatalogEntry = activeId to currentActiveCatalog.copy(products = updatedProducts.toList())

            // Return the new map with the updated catalog
            currentCatalogs.toMutableMap().apply {
                put(updatedCatalogEntry.first, updatedCatalogEntry.second)
            }
            // TODO: Trigger saveCatalogs() here after modification
        }
        dismissDialog() // Close the Add/Edit dialog after confirmation
    }

    fun deleteProduct(productId: String) {
        Log.d(TAG,"Attempting to delete product: $productId")
        _catalogs.update { currentCatalogs ->
            val activeId = _activeCatalogId.value
            val currentActiveCatalog = currentCatalogs[activeId] ?: return@update currentCatalogs

            // Filter out the product to be deleted
            val updatedProducts = currentActiveCatalog.products.filterNot { it.id == productId }

            // If product list actually changed, update the catalog
            if (updatedProducts.size < currentActiveCatalog.products.size) {
                Log.d(TAG,"Product $productId deleted from catalog $activeId")
                currentCatalogs.toMutableMap().apply {
                    this[activeId] = currentActiveCatalog.copy(products = updatedProducts)
                }
                // TODO: Trigger saveCatalogs()
            } else {
                Log.w(TAG,"Product $productId not found for deletion in catalog $activeId")
                currentCatalogs // No change
            }
        }
        // Also remove associated quantity and multiplier assignments if the product is deleted
        _itemQuantities.update { it - productId }
        _productMultiplierAssignments.update { it - productId }
        // Note: We might need confirmation dialog before deleting
    }

    // --- Catalog Selection/Sorting ---
    fun loadCatalog(catalogId: String) {
        if (_catalogs.value.containsKey(catalogId)) {
            if (_activeCatalogId.value != catalogId) {
                _activeCatalogId.value = catalogId
                _itemQuantities.value = emptyMap() // Reset quantities when switching catalogs
                _productMultiplierAssignments.value = emptyMap() // Reset assignments? Maybe per-catalog assignments are better? TODO: Revisit design decision here.
                Log.i(TAG, "Switched active catalog to: $catalogId")
            } else {
                Log.d(TAG, "Catalog $catalogId is already active.")
            }
            dismissDialog() // Close Manage Catalogs dialog if open
        } else {
            Log.w(TAG, "Attempted to load non-existent catalog: $catalogId")
            // TODO: Show user feedback
        }
    }

    fun setSortCriteria(criteria: ProductSortCriteria) {
        _productSortCriteria.value = criteria
        Log.d(TAG, "Product sort criteria set to: $criteria")
    }

    // --- Quantity Management ---
    fun updateQuantity(productId: String, quantityString: String) {
        // Directly update the map with the string value from TextField.
        // Validation (toIntOrNull) happens when building the quote.
        _itemQuantities.update { currentQuantities ->
            currentQuantities.toMutableMap().apply {
                this[productId] = quantityString
            }
        }
        // Log.v(TAG, "Quantity updated for $productId: $quantityString") // Verbose logging
    }

    // --- Multiplier Management ---
    fun setMultiplierToEdit(multiplier: Multiplier?) {
        _multiplierToEdit.value = multiplier
        Log.d(TAG,"Multiplier set/reset for editing: ${multiplier?.id ?: "NEW"}")
        // This function often just prepares state for the dialog.
        // The dialog itself might need logic based on whether _multiplierToEdit is null or not.
    }

    fun addOrUpdateMultiplier(multiplier: Multiplier) {
        _catalogs.update { currentCatalogs ->
            val activeId = _activeCatalogId.value
            val currentActiveCatalog = currentCatalogs[activeId] ?: return@update currentCatalogs

            val existingIndex = currentActiveCatalog.multipliers.indexOfFirst { it.id == multiplier.id }
            val updatedMultipliers = if (existingIndex != -1) {
                Log.d(TAG, "Updating multiplier: ${multiplier.name}")
                currentActiveCatalog.multipliers.toMutableList().apply { this[existingIndex] = multiplier }
            } else {
                Log.d(TAG, "Adding new multiplier: ${multiplier.name}")
                currentActiveCatalog.multipliers + multiplier
            }

            currentCatalogs.toMutableMap().apply {
                this[activeId] = currentActiveCatalog.copy(multipliers = updatedMultipliers.toList())
            }
            // TODO: Trigger saveCatalogs()
        }
        _multiplierToEdit.value = null // Clear edit state after save
        Log.d(TAG,"Multiplier ${multiplier.name} saved.")
        // The ManageMultipliersDialog should probably handle staying open or closing
        // dismissDialog() // Don't automatically dismiss here maybe?
    }

    fun deleteMultiplier(multiplierId: String) {
        Log.d(TAG,"Attempting to delete multiplier: $multiplierId")
        _catalogs.update { currentCatalogs ->
            val activeId = _activeCatalogId.value
            val currentActiveCatalog = currentCatalogs[activeId] ?: return@update currentCatalogs

            val updatedMultipliers = currentActiveCatalog.multipliers.filterNot { it.id == multiplierId }

            if (updatedMultipliers.size < currentActiveCatalog.multipliers.size) {
                Log.d(TAG,"Multiplier $multiplierId deleted from catalog $activeId")
                currentCatalogs.toMutableMap().apply {
                    this[activeId] = currentActiveCatalog.copy(multipliers = updatedMultipliers)
                }
                // TODO: Trigger saveCatalogs()
            } else {
                Log.w(TAG,"Multiplier $multiplierId not found for deletion.")
                currentCatalogs
            }
        }
        // Also remove this multiplier from any active product assignments
        _productMultiplierAssignments.update { currentProdAssignments ->
            currentProdAssignments.mapValues { (_, assignments) ->
                assignments - multiplierId // Remove multiplierId from each product's assignment map
            }.toMutableMap()
        }

        if (_multiplierToEdit.value?.id == multiplierId) {
            _multiplierToEdit.value = null // Clear edit state if the deleted one was being edited
        }
        // Don't dismiss dialog here, let the ManageMultipliersDialog handle UI flow after delete
    }

    // --- Multiplier Assignment ---
    fun confirmMultiplierAssignment(productId: String, assignments: Map<String, Double?>) {
        Log.d(TAG, "Saving assignments for Product $productId: $assignments")
        _productMultiplierAssignments.update { currentAssignments ->
            currentAssignments.toMutableMap().apply {
                this[productId] = assignments // Overwrite assignments for this product
            }
        }
        // Update the UI potentially? Need to display assignments summary on ProductRow.
        // TODO: Enhance ProductRow to show applied multipliers based on _productMultiplierAssignments[productId]
        dismissDialog()
    }


    // --- Tax Rate ---
    fun setTaxRate(newRate: Double) {
        val validatedRate = if(newRate >= 0) newRate else 0.0 // Ensure non-negative
        _taxRate.value = validatedRate
        Log.d(TAG, "Tax rate set to: $validatedRate%")
        // Rebuild quote *if* it's currently being previewed to reflect tax change
        if (_uiMode.value == UiMode.QUOTE_PREVIEW && _currentQuote.value != null) {
            _currentQuote.update { it?.copy(taxRate = validatedRate) }
            Log.d(TAG, "Updated current quote tax rate.")
        }
        dismissDialog()
    }

    // --- Quote Building and Management ---
    private fun buildQuote() { // Make private as it's usually triggered by showQuotePreview
        Log.i(TAG, "Building Quote...")
        val catalog = activeCatalog.value ?: run {
            Log.e(TAG, "Build Quote failed: No active catalog.")
            _currentQuote.value = null
            return
        }
        val quantities = _itemQuantities.value
        val productAssignments = _productMultiplierAssignments.value

        val quoteItems = mutableListOf<QuoteItem>()

        catalog.products.forEach { product ->
            val quantityString = quantities[product.id] ?: "0"
            val quantity = quantityString.toIntOrNull() ?: 0

            if (quantity > 0) {
                // Resolve applied multipliers for this specific item
                val itemAssignments = productAssignments[product.id] ?: emptyMap()
                val appliedMultipliers = itemAssignments.mapNotNull { (multId, overrideValue) ->
                    // Find the global multiplier definition
                    catalog.multipliers.find { it.id == multId }?.let { globalMultiplier ->
                        AppliedMultiplier(
                            multiplierId = multId,
                            name = globalMultiplier.name,
                            type = globalMultiplier.type,
                            // Use the override value if provided, otherwise use the global multiplier's default value
                            appliedValue = overrideValue ?: globalMultiplier.value
                        )
                    }
                }

                quoteItems.add(
                    QuoteItem(
                        product = product.copy(), // Create a copy to snapshot product state
                        quantity = quantity,
                        appliedMultipliers = appliedMultipliers
                    )
                )
            }
        }

        if (quoteItems.isNotEmpty()) {
            val existingQuote = _currentQuote.value // Preserve existing details if just rebuilding items
            _currentQuote.value = Quote(
                id = existingQuote?.id ?: UUID.randomUUID().toString(), // Keep old ID or make new one
                items = quoteItems,
                taxRate = _taxRate.value,
                customerName = existingQuote?.customerName ?: _quoteCustomerName.value, // Keep name if exists
                companyName = existingQuote?.companyName ?: _quoteCompanyName.value, // Keep company if exists
                customMessage = existingQuote?.customMessage ?: _quoteCustomMessage.value // Keep message if exists
            )
            Log.i(TAG, "Quote Built/Updated: ${quoteItems.size} items. Customer: ${_currentQuote.value?.customerName}")
        } else {
            _currentQuote.value = null // No valid items, clear the quote
            Log.i(TAG, "Quote build resulted in no items.")
        }
    }

    fun removeQuoteItem(itemId: String) {
        Log.d(TAG, "Removing quote item: $itemId")
        _currentQuote.update { currentQuoteVal ->
            val updatedItems = currentQuoteVal?.items?.filterNot { it.id == itemId }
            if (updatedItems != null && updatedItems.isNotEmpty()) {
                currentQuoteVal.copy(items = updatedItems)
            } else {
                null // Set quote to null if last item is removed
            }
        }
        if (_currentQuote.value == null) {
            Log.i(TAG,"Last quote item removed. Clearing quote.")
            showCatalogView() // Automatically go back to catalog if quote becomes empty?
        }
    }

    fun updateQuoteDetails(companyName: String, customMessage: String) {
        Log.d(TAG,"Updating quote details - Company: $companyName, Message: $customMessage")
        // Update temporary state used by the dialog input fields
        _quoteCompanyName.value = companyName
        _quoteCustomMessage.value = customMessage
        // Update the actual current quote object if it exists
        _currentQuote.update { quote ->
            quote?.copy(
                companyName = companyName,
                customMessage = customMessage
            )
        }
        dismissDialog()
    }

    // --- Catalog File Management ---
    fun createCatalog(name: String) {
        val trimmedName = name.trim()
        if (trimmedName.isBlank()) {
            Log.w(TAG, "Cannot create catalog with blank name.")
            // TODO: Show error feedback
            return
        }
        val newId = UUID.randomUUID().toString()
        val newCatalog = Catalog(id = newId, name = trimmedName)
        _catalogs.update { it + (newId to newCatalog) }
        Log.i(TAG,"Created new catalog '$trimmedName' ($newId)")
        loadCatalog(newId) // Automatically switch to the newly created catalog
        // TODO: Trigger saveCatalogs()
    }

    fun renameCatalog(catalogId: String, newName: String) {
        val trimmedName = newName.trim()
        if (trimmedName.isBlank()) {
            Log.w(TAG,"Cannot rename catalog $catalogId to blank name.")
            // TODO: Show error feedback
            return
        }
        _catalogs.update { currentCatalogs ->
            currentCatalogs[catalogId]?.let { catalogToRename ->
                Log.i(TAG, "Renaming catalog '$catalogId' from '${catalogToRename.name}' to '$trimmedName'")
                currentCatalogs.toMutableMap().apply {
                    this[catalogId] = catalogToRename.copy(name = trimmedName)
                }
            } ?: run {
                Log.w(TAG,"Catalog $catalogId not found for renaming.")
                currentCatalogs // Return unchanged if ID not found
            }
            // TODO: Trigger saveCatalogs()
        }
    }

    fun deleteCatalog(catalogId: String) {
        if (catalogId == DEFAULT_CATALOG_ID || _catalogs.value.size <= 1) {
            Log.w(TAG, "Cannot delete the last or default catalog: $catalogId")
            // TODO: Show user feedback (Can't delete last catalog)
            return
        }
        Log.i(TAG, "Deleting catalog: $catalogId")
        // TODO: Maybe show a confirmation dialog before deleting?

        _catalogs.update { it - catalogId }
        // If the deleted catalog was active, switch to the default one
        if (_activeCatalogId.value == catalogId) {
            Log.i(TAG,"Deleted catalog was active, switching to default.")
            loadCatalog(DEFAULT_CATALOG_ID) // Switch active ID (loadCatalog handles state reset)
        }
        // TODO: Trigger saveCatalogs()
        // Let dialog handle closing? Don't dismiss here.
    }

    // --- PDF Generation Trigger ---

    /**
     * Triggers PDF generation using the CreateDocument contract approach.
     * This function is called when the MainActivity receives the Uri from the picker.
     * Returns true on success, false on failure.
     */
    fun generatePdf(context: Context, targetUri: Uri): Boolean {
        val quote = _currentQuote.value
        return if (quote != null) {
            if (quote.customerName.isBlank()){
                Log.e(TAG,"PDF Generation failed: Customer name is missing.")
                // TODO: Maybe trigger customer name dialog again?
                // showDialog(DialogState.CUSTOMER_NAME)
                return false
            }
            Log.i(TAG, "Starting PDF generation for quote ID: ${quote.id} to URI: ${targetUri.path}")
            PdfGenerator.generateQuotePdf(context, quote, targetUri) // Delegate to generator
        } else {
            Log.e(TAG, "Attempted to generate PDF but current quote data is null.")
            false
        }
    }

    /**
     * Triggers PDF generation using the OpenDocumentTree contract approach.
     * ViewModel needs to handle writing to the selected directory.
     * NOTE: Requires careful implementation using DocumentFile API or storage frameworks.
     * Returns true on success, false on failure.
     */
    fun generatePdfToUri(context: Context, quote: Quote?, dirUri: Uri, fileName: String): Boolean {
        if (quote == null) {
            Log.e(TAG,"generatePdfToUri failed: Quote data is null.")
            return false
        }
        if (quote.customerName.isBlank()) {
            Log.e(TAG, "generatePdfToUri failed: Customer name is missing.")
            // TODO: Maybe trigger customer name dialog again?
            // showDialog(DialogState.CUSTOMER_NAME)
            return false
        }
        if (fileName.isBlank()){
            Log.e(TAG, "generatePdfToUri failed: Filename is blank.")
            return false
        }

        Log.i(TAG, "Attempting to generate PDF to Directory: ${dirUri.path} with Filename: $fileName")

        // --- Use DocumentFile API for robust directory writing ---
        val parentDocument = DocumentFile.fromTreeUri(context, dirUri)
        if (parentDocument == null || !parentDocument.canWrite()) {
            Log.e(TAG, "Cannot write to selected directory URI: $dirUri")
            // TODO: Show user feedback: Permission issue or invalid directory
            return false
        }

        try {
            // Create the file within the chosen directory
            val pdfFile = parentDocument.createFile("application/pdf", fileName)

            if (pdfFile != null) {
                // Get output stream from the ContentResolver for the new file URI
                context.contentResolver.openOutputStream(pdfFile.uri)?.use { outputStream ->
                    // --- Delegate PDF drawing/writing to PdfGenerator ---
                    // Option A: Modify PdfGenerator to accept an OutputStream
                    // return PdfGenerator.generateQuoteToStream(quote, outputStream)

                    // Option B: (Less clean) Do basic PdfDocument writing here directly
                    val pdfDocument = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(PdfGenerator.PAGE_WIDTH, PdfGenerator.PAGE_HEIGHT, 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val canvas = page.canvas
                    // --- MANUALLY CALL DRAWING LOGIC ON CANVAS (Should ideally be in PdfGenerator) ---
                    // Example placeholder: Draw just the customer name
                    // canvas.drawText("Quote for: ${quote.customerName}", 40f, 60f, Paint().apply{textSize=20f})
                    Log.w(TAG, "PDF Drawing logic needs to be implemented here or called from PdfGenerator using the stream/canvas.")
                    // THIS IS A PLACEHOLDER - Actual drawing needs the complex logic from PdfGenerator
                    // pdfDocument.drawContent(canvas, quote) // Assume drawContent exists in PdfGenerator
                    pdfDocument.finishPage(page)

                    pdfDocument.writeTo(outputStream) // Write PDF content to the stream
                    pdfDocument.close() // Close the document
                    Log.i(TAG, "Successfully wrote PDF to DocumentFile: ${pdfFile.uri}")
                    return true // Success!

                } ?: throw IOException("Could not get OutputStream for DocumentFile URI: ${pdfFile.uri}")
            } else {
                Log.e(TAG, "Failed to create DocumentFile with name '$fileName' in directory.")
                // Maybe filename conflict? Illegal characters?
                return false
            }
        } catch (e: Exception) {
            // Catch any IOExceptions during stream operations or other errors
            Log.e(TAG, "Error writing PDF via DocumentFile API", e)
            // Clean up potentially created file if it exists? pdfFile?.delete()
            return false
        }
    }

} // End of MainViewModel class