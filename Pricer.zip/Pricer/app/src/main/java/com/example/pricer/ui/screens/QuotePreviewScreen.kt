package com.example.pricer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed // Use indexed items for dividers perhaps
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.* // Common icons
import androidx.compose.material.icons.outlined.DeleteOutline // Outline delete icon
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pricer.data.model.DialogState // Need dialog state
import com.example.pricer.data.model.MultiplierType // Need multiplier type for display
import com.example.pricer.data.model.Quote // Need Quote model
import com.example.pricer.data.model.QuoteItem // Need QuoteItem model
import com.example.pricer.util.formatCurrency // Currency formatting
import com.example.pricer.util.formatPercentage // Percentage formatting
import com.example.pricer.viewmodel.MainViewModel // Need ViewModel

/**
 * Screen composable for previewing the generated quote.
 * Shows customer details, line items with multipliers, totals, and allows PDF generation.
 *
 * @param viewModel The instance of [MainViewModel].
 * @param onNavigateBack Callback to navigate back to the Catalog screen.
 * @param onGeneratePdfClick Callback to initiate the PDF generation process.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuotePreviewScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onGeneratePdfClick: () -> Unit // Callback to trigger PDF logic in Activity/higher level
) {
    // --- State Collection ---
    val quote by viewModel.currentQuote.collectAsStateWithLifecycle() // Observe the current quote

    // Remember the specific quote instance to avoid recomposition if irrelevant parts change
    val currentQuote = remember(quote?.id) { quote }

    // --- Screen Structure ---
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Quote Preview") },
                // Back button to return to catalog
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to Catalog")
                    }
                },
                actions = {
                    // --- Edit Quote Details Button ---
                    IconButton(onClick = { viewModel.showDialog(DialogState.QUOTE_DETAILS) }) {
                        Icon(Icons.Default.Info, contentDescription = "Edit Quote Details") // Or EditNote icon?
                    }
                    // --- Set Tax Rate Button ---
                    IconButton(onClick = { viewModel.showDialog(DialogState.SET_TAX) }) {
                        Icon(Icons.Default.Percent, contentDescription = "Set Tax Rate") // Percent icon
                    }
                }
            )
        }, // End of topBar

        floatingActionButton = {
            // Show Generate PDF button only if there is a valid quote with items
            if (currentQuote != null && currentQuote.items.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                    text = { Text("Generate PDF") },
                    onClick = onGeneratePdfClick // Trigger PDF generation via callback
                )
            }
        } // End of floatingActionButton
    ) { scaffoldPadding ->

        // --- Handle Empty/Null Quote State ---
        if (currentQuote == null || currentQuote.items.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(scaffoldPadding) // Respect scaffold padding
                    .padding(16.dp), // Additional padding
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (currentQuote == null) "Error generating quote." else "No items in the quote.",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
            }
            return@Scaffold // Exit early if no quote to display
        }

        // --- Quote Content (LazyColumn) ---
        // We know quoteData is not null here because of the early return
        val quoteData = currentQuote

        LazyColumn(
            modifier = Modifier
                .padding(scaffoldPadding) // Apply scaffold padding
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp) // Padding for content
        ) {
            // --- Header Section ---
            item(key = "quote_header") {
                // Customer Name (required)
                Text(
                    "Quote For: ${quoteData.customerName}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))

                // Company Name (optional)
                if (quoteData.companyName.isNotBlank()) {
                    Text(
                        "From: ${quoteData.companyName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                // Custom Message (optional)
                if (quoteData.customMessage.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        quoteData.customMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                Divider(modifier = Modifier.padding(vertical = 12.dp))
            }

            // --- Line Items Header Row ---
            item(key = "line_item_header") {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Use weights for flexible columns
                    Text("Item", modifier = Modifier.weight(2.5f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge) // More space for Item/Desc
                    Text("Qty", modifier = Modifier.weight(0.6f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End, style = MaterialTheme.typography.labelLarge)
                    Text("Price", modifier = Modifier.weight(1.0f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End, style = MaterialTheme.typography.labelLarge)
                    Text("Total", modifier = Modifier.weight(1.1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End, style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.width(40.dp)) // Spacer for alignment with delete icon below
                }
                Divider(thickness = 1.dp) // Thicker divider under header
                Spacer(modifier = Modifier.height(8.dp))
            }


            // --- Quote Items List ---
            itemsIndexed(
                items = quoteData.items,
                key = { _, item -> "item_${item.id}" } // Unique key for each item
            ) { index, item ->
                QuoteLineItem( // Use the helper composable
                    item = item,
                    onRemoveItem = { viewModel.removeQuoteItem(item.id) } // Call VM to remove
                )
                // Add subtle divider between items, but not after the last one
                if (index < quoteData.items.lastIndex) {
                    Divider(modifier = Modifier.padding(vertical = 6.dp), thickness = 0.5.dp)
                }
            }

            // --- Totals Section ---
            item(key = "quote_totals") {
                Spacer(modifier = Modifier.height(16.dp))
                Divider(thickness = 1.dp) // Thicker divider above totals
                Spacer(modifier = Modifier.height(8.dp))

                // Use helper composable for consistent total rows
                TotalsRow(label = "Subtotal:", value = formatCurrency(quoteData.subtotal))
                TotalsRow(label = "Tax (${formatPercentage(quoteData.taxRate)}):", value = formatCurrency(quoteData.taxAmount))
                TotalsRow(label = "Grand Total:", value = formatCurrency(quoteData.grandTotal), isBold = true)

                Spacer(modifier = Modifier.height(96.dp)) // Space below totals for FAB overlap
            }
        } // End of LazyColumn
    } // End of Scaffold
}


// --- Helper Composable for a single Quote Line Item ---
@Composable
private fun QuoteLineItem(
    item: QuoteItem,
    onRemoveItem: () -> Unit,
    // TODO: Consider adding onQuantityChange: (Int) -> Unit if inline editing is desired here
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top // Align tops of elements in the row
    ) {
        // --- Item Name, Description, Multipliers ---
        Column(modifier = Modifier.weight(2.5f).padding(end = 8.dp)) { // Same weight as header
            Text(
                text = item.product.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            // Optional Description
            if (item.product.description.isNotEmpty()) {
                Text(
                    text = item.product.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            // List Applied Multipliers
            item.appliedMultipliers.forEach { mult ->
                val valueStr = when (mult.type) {
                    MultiplierType.PERCENTAGE -> formatPercentage(mult.appliedValue)
                    MultiplierType.FIXED_PER_UNIT -> "${formatCurrency(mult.appliedValue)}/unit"
                }
                Text(
                    text = "  + ${mult.name} ($valueStr)",
                    style = MaterialTheme.typography.labelSmall, // Use small label style
                    color = MaterialTheme.colorScheme.primary // Highlight with primary color
                )
            }
        }

        // --- Quantity ---
        Text(
            text = item.quantity.toString(),
            modifier = Modifier.weight(0.6f).padding(top = 2.dp), // Align baseline roughly
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End
        )
        // --- Unit Price ---
        Text(
            text = formatCurrency(item.product.basePrice),
            modifier = Modifier.weight(1.0f).padding(top = 2.dp),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End
        )
        // --- Line Total ---
        Text(
            text = formatCurrency(item.lineTotal),
            modifier = Modifier.weight(1.1f).padding(top = 2.dp),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End
        )
        // --- Remove Item Button ---
        // Use IconButton for proper touch target size
        IconButton(
            onClick = onRemoveItem,
            modifier = Modifier.size(40.dp).align(Alignment.CenterVertically) // Make icon button clickable
        ) {
            Icon(
                imageVector = Icons.Outlined.DeleteOutline,
                contentDescription = "Remove ${item.product.name}",
                tint = MaterialTheme.colorScheme.error // Use error color for delete actions
            )
        }
    } // End of Row
} // End of QuoteLineItem


// --- Helper Composable for displaying total rows consistently ---
@Composable
private fun TotalsRow(
    label: String,
    value: String,
    isBold: Boolean = false // Optionally make row bold (e.g., Grand Total)
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp), // Space between total lines
        horizontalArrangement = Arrangement.End, // Align content towards the end (right)
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Use a spacer to push the text fully to the right if desired
        // Spacer(modifier = Modifier.weight(1f)) // Pushes text to the end

        Text(
            text = label,
            // Keep alignment to Start or End based on where value should align
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f), // Allow label to take space needed
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Spacer(modifier = Modifier.width(24.dp)) // Consistent spacing between label and value
        Text(
            text = value,
            textAlign = TextAlign.End, // Ensure value is also right aligned
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
    }
}