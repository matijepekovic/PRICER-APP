package com.example.pricer.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.* // Add, Delete, Edit, Save, Check, Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.pricer.data.model.Catalog

/**
 * Dialog for managing multiple Catalogs: Selecting the active one, adding new ones,
 * renaming existing ones, and deleting them.
 *
 * @param catalogs The map of all available catalogs (ID -> Catalog object).
 * @param activeCatalogId The ID of the currently active catalog.
 * @param onDismiss Lambda to dismiss the dialog.
 * @param onSelectCatalog Lambda called when a catalog is selected. Passes the catalog ID.
 * @param onAddCatalog Lambda called to add a new catalog. Passes the desired name.
 * @param onRenameCatalog Lambda called to rename a catalog. Passes the catalog ID and the new name.
 * @param onDeleteCatalog Lambda called to delete a catalog. Passes the catalog ID.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageCatalogsDialog(
    catalogs: Map<String, Catalog>,
    activeCatalogId: String,
    onDismiss: () -> Unit,
    onSelectCatalog: (String) -> Unit,
    onAddCatalog: (String) -> Unit,
    onRenameCatalog: (id: String, newName: String) -> Unit,
    onDeleteCatalog: (id: String) -> Unit
    // TODO: Add callbacks for Load All / Save All persistence actions if needed
) {
    // --- State within the Dialog ---
    // State to control the visibility and input for adding a new catalog
    var showAddCatalogInput by remember { mutableStateOf(false) }
    var newCatalogName by remember { mutableStateOf("") }

    // State to track which catalog is currently being renamed (ID) and the temporary name
    var renamingCatalogId by remember { mutableStateOf<String?>(null) }
    var renameCatalogNewName by remember { mutableStateOf("") }

    // State to control the delete confirmation dialog
    var showDeleteConfirmation by remember { mutableStateOf<String?>(null) } // Holds ID to delete

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = MaterialTheme.shapes.large) {
            Column(modifier = Modifier.padding(16.dp)) {
                // --- Dialog Title ---
                Text("Manage Catalogs", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 12.dp))

                // --- Add New Catalog Section ---
                if (showAddCatalogInput) {
                    // Show input field and confirmation buttons
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCatalogName,
                            onValueChange = { newCatalogName = it },
                            label = { Text("New Catalog Name") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        IconButton(
                            onClick = {
                                if (newCatalogName.isNotBlank()) {
                                    onAddCatalog(newCatalogName.trim())
                                    newCatalogName = "" // Clear field
                                    showAddCatalogInput = false // Hide input
                                }
                                // TODO: Add error handling for blank name? (ViewModel might handle it too)
                            },
                            enabled = newCatalogName.isNotBlank()
                        ) { Icon(Icons.Filled.Check, contentDescription = "Confirm Add") }
                        IconButton(onClick = { showAddCatalogInput = false; newCatalogName = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Cancel Add")
                        }
                    }
                } else {
                    // Show "Add New" button
                    Button(
                        onClick = { showAddCatalogInput = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(ButtonDefaults.IconSize))
                        Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                        Text("Add New Catalog")
                    }
                }
                Divider(modifier = Modifier.padding(vertical = 12.dp))

                // --- List of Existing Catalogs ---
                Text("Available Catalogs:", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) { // Limit height
                    items(items = catalogs.values.toList(), key = { it.id }) { catalog ->

                        // Check if this catalog is the one being renamed
                        val isRenamingThis = renamingCatalogId == catalog.id

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isRenamingThis) { onSelectCatalog(catalog.id) } // Allow selecting if not renaming
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Show checkmark for the active catalog
                            if (catalog.id == activeCatalogId) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = "Active Catalog", tint = MaterialTheme.colorScheme.primary)
                            } else {
                                // Placeholder for alignment if needed, or just use padding
                                Spacer(modifier = Modifier.width(24.dp)) // Width of the checkmark icon
                            }
                            Spacer(Modifier.width(8.dp))

                            // Display Name (or TextField if renaming)
                            if (isRenamingThis) {
                                OutlinedTextField(
                                    value = renameCatalogNewName,
                                    onValueChange = { renameCatalogNewName = it },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    label = { Text("New Name") }
                                )
                                // Save Rename Button
                                IconButton(onClick = {
                                    if (renameCatalogNewName.isNotBlank()){
                                        onRenameCatalog(catalog.id, renameCatalogNewName.trim())
                                    }
                                    renamingCatalogId = null // Exit rename mode
                                }, enabled = renameCatalogNewName.isNotBlank()) {
                                    Icon(Icons.Filled.Save, contentDescription = "Save Rename")
                                }
                                // Cancel Rename Button
                                IconButton(onClick = { renamingCatalogId = null }) {
                                    Icon(Icons.Filled.Cancel, contentDescription = "Cancel Rename")
                                }

                            } else {
                                // Display Catalog Name
                                Text(
                                    text = catalog.name,
                                    modifier = Modifier.weight(1f), // Allow name to take space
                                    fontWeight = if (catalog.id == activeCatalogId) FontWeight.Bold else FontWeight.Normal
                                )
                                // Rename Button
                                IconButton(onClick = {
                                    renamingCatalogId = catalog.id
                                    renameCatalogNewName = catalog.name // Pre-fill with current name
                                }, enabled = renamingCatalogId == null && !showAddCatalogInput) { // Disable if already renaming/adding
                                    Icon(Icons.Filled.Edit, contentDescription = "Rename ${catalog.name}")
                                }
                                // Delete Button (Show only if not active and not the default/last one?)
                                val canDelete = catalog.id != activeCatalogId && catalogs.size > 1 // Basic safety check
                                IconButton(onClick = { showDeleteConfirmation = catalog.id }, enabled = canDelete && renamingCatalogId == null && !showAddCatalogInput) {
                                    Icon(
                                        Icons.Filled.DeleteOutline,
                                        contentDescription = "Delete ${catalog.name}",
                                        tint = if(canDelete) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f) // Dim if disabled
                                    )
                                }
                            } // End else (displaying name)
                        } // End Row for catalog item
                        Divider()
                    } // End items loop
                } // End LazyColumn

                // --- Dialog Close Button ---
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End){
                    TextButton(onClick = onDismiss) {
                        Text("Close")
                    }
                }


                // --- TODO: Add Load/Save All Buttons if implementing persistence here ---
                // Row(...) { Button("Load All"){...}; Button("Save All"){...} }


            } // End Main Column
        } // End Card

        // --- Delete Confirmation Dialog ---
        if (showDeleteConfirmation != null) {
            val catalogToDelete = catalogs[showDeleteConfirmation]
            AlertDialog(
                onDismissRequest = { showDeleteConfirmation = null },
                title = { Text("Confirm Deletion") },
                text = { Text("Are you sure you want to delete the catalog \"${catalogToDelete?.name ?: "Unknown"}\"? This will delete all products and multipliers within it and cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            onDeleteCatalog(showDeleteConfirmation!!)
                            showDeleteConfirmation = null // Close confirm dialog
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) { Text("Delete", color = MaterialTheme.colorScheme.onError) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmation = null }) { Text("Cancel") }
                }
            )
        } // End Delete Confirmation

    } // End Main Dialog
}