package com.example.pricer.ui.dialogs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.* // Add, Edit, Delete, Save
import androidx.compose.material.icons.outlined.Info // For empty list
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.pricer.data.model.Multiplier
import com.example.pricer.data.model.MultiplierType
import com.example.pricer.util.formatCurrency
import com.example.pricer.util.formatPercentage
import java.util.UUID

/**
 * Dialog composable for managing global Multipliers (Add, View, Edit, Delete).
 *
 * @param multipliers The current list of multipliers in the active catalog.
 * @param onDismiss Lambda to dismiss the dialog.
 * @param onAddMultiplier Callback passing the newly created Multiplier to the ViewModel.
 * @param onUpdateMultiplier Callback passing the updated Multiplier to the ViewModel.
 * @param onDeleteMultiplier Callback passing the ID of the Multiplier to delete.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageMultipliersDialog(
    multipliers: List<Multiplier>,
    onDismiss: () -> Unit,
    onAddMultiplier: (Multiplier) -> Unit,
    onUpdateMultiplier: (Multiplier) -> Unit,
    onDeleteMultiplier: (String) -> Unit // Pass ID to delete
) {
    // --- State Management within the Dialog ---
    // ID of the multiplier currently being edited (null if adding new)
    var editingMultiplierId by remember { mutableStateOf<String?>(null) }
    // State for the input fields when adding/editing
    var currentName by remember { mutableStateOf("") }
    var currentValueString by remember { mutableStateOf("") }
    var currentType by remember { mutableStateOf(MultiplierType.PERCENTAGE) }
    // State to control confirmation dialog for delete
    var showDeleteConfirmation by remember { mutableStateOf<String?>(null) } // Holds ID to delete

    // Reset fields when editingMultiplierId changes
    LaunchedEffect(editingMultiplierId) {
        val multToEdit = multipliers.find { it.id == editingMultiplierId }
        currentName = multToEdit?.name ?: ""
        currentValueString = multToEdit?.value?.takeIf { it != 0.0 }?.toString() ?: ""
        currentType = multToEdit?.type ?: MultiplierType.PERCENTAGE
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = MaterialTheme.shapes.large) {
            Column(modifier = Modifier.padding(16.dp)) {
                // --- Dialog Title ---
                Text(
                    text = "Manage Multipliers",
                    style = MaterialTheme.typography.headlineSmall,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // --- Add/Edit Section (conditionally visible) ---
                if (editingMultiplierId != null) { // Show edit fields if editing or adding (ID can be "NEW")
                    EditMultiplierFields(
                        isAdding = editingMultiplierId == "NEW", // Special ID marker for adding
                        name = currentName,
                        valueString = currentValueString,
                        type = currentType,
                        onNameChange = { currentName = it },
                        onValueChange = { currentValueString = it },
                        onTypeChange = { currentType = it },
                        onSave = { name, value, type ->
                            val multiplier = Multiplier(
                                id = if (editingMultiplierId == "NEW") UUID.randomUUID().toString() else editingMultiplierId!!,
                                name = name,
                                value = value,
                                type = type
                            )
                            if (editingMultiplierId == "NEW") {
                                onAddMultiplier(multiplier)
                            } else {
                                onUpdateMultiplier(multiplier)
                            }
                            editingMultiplierId = null // Exit edit mode after save
                        },
                        onCancel = { editingMultiplierId = null } // Exit edit mode on cancel
                    )
                    Divider(modifier = Modifier.padding(vertical = 12.dp))
                }

                // --- Button to Enter Add Mode ---
                // Only show if *not* currently adding/editing
                if (editingMultiplierId == null) {
                    Button(
                        onClick = { editingMultiplierId = "NEW" }, // Set special ID to indicate adding
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(ButtonDefaults.IconSize))
                        Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                        Text("Add New Multiplier")
                    }
                    Spacer(Modifier.height(12.dp))
                }

                // --- List of Existing Multipliers ---
                Text("Existing Multipliers:", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                if (multipliers.isEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(8.dp))
                        Text("No multipliers defined yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) { // Limit height and make scrollable
                        items(items = multipliers, key = { it.id }) { multiplier ->
                            MultiplierListItem(
                                multiplier = multiplier,
                                onEditClick = { editingMultiplierId = multiplier.id }, // Enter edit mode for this ID
                                onDeleteClick = { showDeleteConfirmation = multiplier.id } // Show delete confirm dialog
                            )
                            Divider()
                        }
                    }
                } // End else (multipliers list)


                // --- Close Button ---
                // Show only if not adding/editing, otherwise rely on EditFields' Cancel/Save
                if(editingMultiplierId == null){
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End){
                        TextButton(onClick = onDismiss) {
                            Text("Close")
                        }
                    }
                }


            } // End Column
        } // End Card

        // --- Delete Confirmation Dialog ---
        if (showDeleteConfirmation != null) {
            val multiplierToDelete = multipliers.find { it.id == showDeleteConfirmation }
            AlertDialog(
                onDismissRequest = { showDeleteConfirmation = null }, // Dismiss confirmation
                title = { Text("Confirm Deletion") },
                text = { Text("Are you sure you want to delete the multiplier \"${multiplierToDelete?.name ?: "Unknown"}\"? This cannot be undone.") },
                confirmButton = {
                    Button(
                        onClick = {
                            onDeleteMultiplier(showDeleteConfirmation!!)
                            showDeleteConfirmation = null // Close dialog after deletion
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) { Text("Delete", color= MaterialTheme.colorScheme.onError) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirmation = null }) { Text("Cancel") }
                }
            )
        } // End Delete Confirmation


    } // End Dialog
}


// --- Helper Composable for displaying a single multiplier in the list ---
@Composable
private fun MultiplierListItem(
    multiplier: Multiplier,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(multiplier.name, style = MaterialTheme.typography.bodyLarge)
            val valueText = when (multiplier.type) {
                MultiplierType.PERCENTAGE -> formatPercentage(multiplier.value)
                MultiplierType.FIXED_PER_UNIT -> "${formatCurrency(multiplier.value)} / unit"
            }
            Text(
                "${multiplier.type.name.lowercase().replaceFirstChar { it.titlecase() }} ($valueText)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onEditClick) {
            Icon(Icons.Filled.Edit, contentDescription = "Edit ${multiplier.name}")
        }
        IconButton(onClick = onDeleteClick) {
            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete ${multiplier.name}", tint = MaterialTheme.colorScheme.error)
        }
    }
}


// --- Helper Composable for the Add/Edit Input Fields ---
@Composable
private fun EditMultiplierFields(
    isAdding: Boolean,
    name: String,
    valueString: String,
    type: MultiplierType,
    onNameChange: (String) -> Unit,
    onValueChange: (String) -> Unit,
    onTypeChange: (MultiplierType) -> Unit,
    onSave: (name: String, value: Double, type: MultiplierType) -> Unit,
    onCancel: () -> Unit
) {
    var nameError by remember { mutableStateOf<String?>(null) }
    var valueError by remember { mutableStateOf<String?>(null) }

    Column {
        Text(if(isAdding) "Add New Multiplier Details" else "Edit Multiplier", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        // --- Name Field ---
        OutlinedTextField(
            value = name,
            onValueChange = { onNameChange(it); nameError = null },
            label = { Text("Multiplier Name*") },
            isError = nameError != null,
            supportingText = nameError?.let { { Text(it) } },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))

        // --- Type Selector ---
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Type:", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.width(8.dp))
            MultiplierType.entries.forEach { multiplierType ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = type == multiplierType,
                        onClick = { onTypeChange(multiplierType) }
                    )
                    Text(multiplierType.name.lowercase().replaceFirstChar { it.titlecase() }, modifier = Modifier.clickable { onTypeChange(multiplierType) }.padding(end = 8.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))


        // --- Value Field ---
        OutlinedTextField(
            value = valueString,
            onValueChange = { newValue ->
                if (newValue.matches(Regex("^\\d*\\.?\\d*\$")) || newValue.isEmpty()) {
                    onValueChange(newValue)
                    valueError = null
                }
            },
            label = { Text("Value*") },
            isError = valueError != null,
            supportingText = valueError?.let { { Text(it) } },
            leadingIcon = if (type == MultiplierType.FIXED_PER_UNIT) ({ Text("$") }) else null,
            trailingIcon = if (type == MultiplierType.PERCENTAGE) ({ Text("%") }) else null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(16.dp))


        // --- Save/Cancel Buttons for Edit Section ---
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                // Validation
                val valueDouble = valueString.toDoubleOrNull()
                var isValid = true
                if (name.isBlank()){ nameError = "Name cannot be empty"; isValid = false }
                if (valueDouble == null || valueDouble < 0) { valueError = "Enter a valid value"; isValid = false }

                if(isValid) {
                    onSave(name.trim(), valueDouble!!, type)
                }
            }) {
                Icon(Icons.Filled.Save, contentDescription=null, modifier=Modifier.size(ButtonDefaults.IconSize))
                Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                Text("Save")
            }
        }
    }
}