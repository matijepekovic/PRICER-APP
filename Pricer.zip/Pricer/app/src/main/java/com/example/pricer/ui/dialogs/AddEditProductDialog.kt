package com.example.pricer.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.* // remember, mutableStateOf, etc.
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.pricer.data.model.Product
import java.util.UUID

/**
 * A Dialog composable for adding a new product or editing an existing one.
 * Includes fields for name, description, unit type, base price, and category.
 * Performs basic validation before confirming.
 *
 * @param productToEdit The [Product] object to edit. If null, the dialog is in 'Add' mode.
 * @param onDismiss Lambda function to be invoked when the dialog should be dismissed (e.g., click outside, Cancel button).
 * @param onConfirm Lambda function to be invoked when the Add/Save button is clicked. Passes the new or updated [Product].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    productToEdit: Product?, // Null means we are adding a new product
    onDismiss: () -> Unit,
    onConfirm: (Product) -> Unit // Callback with the resulting product
) {
    // --- State Management for Input Fields ---
    // Use 'remember' with productToEdit as key to reset fields when dialog opens for different products
    var name by remember(productToEdit) { mutableStateOf(productToEdit?.name ?: "") }
    var description by remember(productToEdit) { mutableStateOf(productToEdit?.description ?: "") }
    var unitType by remember(productToEdit) { mutableStateOf(productToEdit?.unitType ?: "unit") }
    var basePriceString by remember(productToEdit) { mutableStateOf(productToEdit?.basePrice?.takeIf { it != 0.0 }?.toString() ?: "") } // Show 0 as blank initially
    var category by remember(productToEdit) { mutableStateOf(productToEdit?.category ?: "Default") }

    // State for validation errors
    var nameError by remember { mutableStateOf<String?>(null) }
    var priceError by remember { mutableStateOf<String?>(null) }

    // Helper for managing keyboard focus
    val focusManager = LocalFocusManager.current

    // --- Dialog Structure ---
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = MaterialTheme.shapes.large // Use a larger shape for dialogs
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    // Make column scrollable if content exceeds screen height
                    .verticalScroll(rememberScrollState())
            ) {
                // --- Dialog Title ---
                Text(
                    text = if (productToEdit == null) "Add New Product" else "Edit Product",
                    style = MaterialTheme.typography.headlineSmall, // Dialog title style
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // --- Product Name Input ---
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; nameError = null }, // Clear error on change
                    label = { Text("Product Name*") }, // Asterisk indicates required
                    isError = nameError != null,
                    supportingText = nameError?.let { { Text(it) } }, // Display error message
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        imeAction = ImeAction.Next // Move to next field on keyboard action
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                // --- Product Description Input ---
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp), // Give some space
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        imeAction = ImeAction.Next
                    ),
                    maxLines = 4 // Allow multiple lines for description
                )
                Spacer(modifier = Modifier.height(8.dp))

                // --- Price and Unit Type Row ---
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), // Space between fields
                    verticalAlignment = Alignment.Top // Align tops if fields differ in height
                ) {
                    // --- Base Price Input ---
                    OutlinedTextField(
                        value = basePriceString,
                        onValueChange = { newValue ->
                            // Allow only valid decimal input (digits, optional single dot)
                            if (newValue.matches(Regex("^\\d*\\.?\\d*\$"))) {
                                basePriceString = newValue
                                priceError = null // Clear error on valid input
                            } else if (newValue.isEmpty()) {
                                // Allow clearing the field
                                basePriceString = ""
                                priceError = null
                            }
                        },
                        label = { Text("Base Price*") },
                        isError = priceError != null,
                        supportingText = priceError?.let { { Text(it) } },
                        modifier = Modifier.weight(1f), // Take half the space
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal, // Number keyboard with decimal
                            imeAction = ImeAction.Next
                        ),
                        leadingIcon = { Text(text = "$") }, // Example currency symbol
                        singleLine = true
                    )

                    // --- Unit Type Input ---
                    OutlinedTextField(
                        value = unitType,
                        onValueChange = { unitType = it },
                        label = { Text("Unit Type") }, // E.g., "kg", "hour", "item"
                        modifier = Modifier.weight(1f), // Take half the space
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.None,
                            imeAction = ImeAction.Next
                        ),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                // --- Category Input ---
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        imeAction = ImeAction.Done // Final field, use 'Done' action
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { focusManager.clearFocus() } // Hide keyboard on Done
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))

                // --- Action Buttons (Cancel, Save/Add) ---
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End // Align buttons to the right
                ) {
                    // Cancel Button
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp)) // Space between buttons

                    // Confirm Button (Add or Save)
                    Button(onClick = {
                        // --- Validation Logic ---
                        val priceDouble = basePriceString.toDoubleOrNull()
                        var isValid = true

                        // Validate Name
                        if (name.isBlank()) {
                            nameError = "Name cannot be empty"
                            isValid = false
                        } else {
                            nameError = null
                        }

                        // Validate Price
                        if (priceDouble == null || priceDouble < 0) {
                            priceError = "Enter a valid price (e.g., 0 or more)"
                            isValid = false
                        } else {
                            priceError = null
                        }

                        // If all validation passes...
                        if (isValid) {
                            // Ensure default values if left blank by user
                            val finalUnitType = unitType.ifBlank { "unit" }
                            val finalCategory = category.ifBlank { "Default" }

                            // Create or update the Product object
                            val finalProduct = Product(
                                id = productToEdit?.id ?: UUID.randomUUID().toString(), // Keep existing ID or generate new
                                name = name.trim(),
                                description = description.trim(),
                                unitType = finalUnitType.trim(),
                                basePrice = priceDouble!!, // Safe due to validation check
                                category = finalCategory.trim()
                            )
                            // Call the confirmation callback with the result
                            onConfirm(finalProduct)
                        }
                        // --- End of Validation Logic ---
                    }) {
                        Text(if (productToEdit == null) "Add" else "Save")
                    }
                } // End of Button Row
            } // End of Column
        } // End of Card
    } // End of Dialog
}