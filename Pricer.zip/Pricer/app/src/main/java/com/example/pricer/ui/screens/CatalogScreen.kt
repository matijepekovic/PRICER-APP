package com.example.pricer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.* // Common icons
import androidx.compose.material.icons.outlined.Info // Example Outline Icon
import androidx.compose.material3.*
import androidx.compose.runtime.* // remember, mutableStateOf, getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle // Use lifecycle-aware collection
import com.example.pricer.data.model.DialogState // Need dialog enum
import com.example.pricer.data.model.Product // Need Product model
import com.example.pricer.data.model.ProductSortCriteria // Need sort enum
import com.example.pricer.ui.components.ProductRow // Import the row component
import com.example.pricer.viewmodel.MainViewModel // Need the ViewModel

/**
 * The main screen for displaying and managing the product catalog.
 * Shows a list of products, allows adding/editing, setting quantities,
 * managing multipliers/catalogs via TopAppBar actions, and navigating to the quote preview.
 *
 * @param viewModel The instance of [MainViewModel] providing data and handling logic.
 * @param onNavigateToQuotePreview Callback lambda function to trigger navigation/mode switch
 *                                  to the quote preview screen/state.
 */
@OptIn(ExperimentalMaterial3Api::class) // For Scaffold, TopAppBar etc.
@Composable
fun CatalogScreen(
    viewModel: MainViewModel,
    onNavigateToQuotePreview: () -> Unit, // Simple callback to trigger navigation/VM logic
) {
    // --- State Collection ---
    // Observe state flows from the ViewModel in a lifecycle-aware manner
    val sortedProducts by viewModel.sortedProducts.collectAsStateWithLifecycle()
    val quantities by viewModel.itemQuantities.collectAsStateWithLifecycle()
    val currentCatalog by viewModel.activeCatalog.collectAsStateWithLifecycle() // Observe active catalog name/details
    val sortCriteria by viewModel.productSortCriteria.collectAsStateWithLifecycle()
    // TODO: Observe productMultiplierAssignments later to pass summary to ProductRow
    val productAssignments by viewModel.productMultiplierAssignments.collectAsStateWithLifecycle() // <-- Added for summary later


    // --- UI Helpers ---
    val focusManager = LocalFocusManager.current // To clear focus (e.g., hide keyboard)
    var showSortMenu by remember { mutableStateOf(false) } // State for sort dropdown visibility

    // --- Main Screen Structure ---
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    // Display current catalog name, fallback if null
                    Text(currentCatalog?.name ?: "Catalog Loading...")
                },
                actions = {
                    // --- Sort Button and Dropdown Menu ---
                    Box { // Needed to position the DropdownMenu correctly relative to the IconButton
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Sort Products")
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false } // Close menu if clicked outside
                        ) {
                            // Create a menu item for each sorting criteria
                            ProductSortCriteria.entries.forEach { criteria ->
                                DropdownMenuItem(
                                    text = {
                                        // Format enum name for display (e.g., NAME_ASC -> "Name Asc")
                                        Text(
                                            criteria.name.replace("_", " ")
                                                .lowercase()
                                                .replaceFirstChar { it.titlecase() }
                                        )
                                    },
                                    onClick = {
                                        viewModel.setSortCriteria(criteria) // Tell VM to sort
                                        showSortMenu = false // Close menu
                                    },
                                    // Show a checkmark next to the currently active sort criteria
                                    leadingIcon = if (sortCriteria == criteria) {
                                        { Icon(Icons.Default.Check, contentDescription = "Selected Criteria") }
                                    } else null
                                )
                            }
                        }
                    } // End of Sort Button Box

                    // --- Manage Catalogs Button ---
                    IconButton(onClick = {
                        focusManager.clearFocus() // Clear focus before opening dialog
                        viewModel.showDialog(DialogState.MANAGE_CATALOGS)
                    }) {
                        Icon(Icons.Default.FolderCopy, contentDescription = "Manage Catalogs") // Changed icon
                    }

                    // --- Manage Multipliers (Settings) Button ---
                    IconButton(onClick = {
                        focusManager.clearFocus()
                        viewModel.showDialog(DialogState.MANAGE_MULTIPLIERS)
                    }) {
                        Icon(Icons.Default.Tune, contentDescription = "Manage Multipliers") // Changed icon to Tune
                    }
                } // End of actions
            )
        }, // End of topBar

        floatingActionButton = {
            // Arrange multiple FABs if needed
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp), // Space between FABs
                verticalAlignment = Alignment.CenterVertically
            ) {
                // --- Add Product FAB ---
                FloatingActionButton(
                    onClick = {
                        focusManager.clearFocus() // Dismiss keyboard
                        // Show dialog to add NEW product (pass null data)
                        viewModel.showDialog(DialogState.ADD_EDIT_PRODUCT, null)
                    },
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add New Product")
                }

                // --- Preview Quote FAB (Conditional) ---
                // Only show if at least one item has a quantity > 0
                val hasItemsWithQuantity = quantities.any { (_, qtyStr) ->
                    (qtyStr.toIntOrNull() ?: 0) > 0
                }
                if (hasItemsWithQuantity) {
                    ExtendedFloatingActionButton(
                        icon = { Icon(Icons.Default.ReceiptLong, contentDescription = null) },
                        text = { Text("Preview Quote") },
                        onClick = {
                            focusManager.clearFocus() // Dismiss keyboard before navigating/processing
                            onNavigateToQuotePreview() // Trigger the callback/VM logic
                        },
                        expanded = true // Keep text visible or use scroll behavior if needed
                    )
                }
            } // End of Row for FABs
        } // End of floatingActionButton
    ) { scaffoldPadding -> // Content area provided by Scaffold

        Column(
            modifier = Modifier
                .padding(scaffoldPadding) // Apply padding from Scaffold (for AppBars, FABs)
                .fillMaxSize() // Fill available space
        ) {
            // --- Handle Empty Catalog State ---
            if (sortedProducts.isEmpty() && currentCatalog != null) {
                // Check currentCatalog != null to avoid showing this during initial loading
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center // Center the message
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Info, // Example Icon
                            contentDescription = null,
                            modifier = Modifier.size(48.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Catalog is empty.",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Tap the '+' button to add your first product.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            // --- Display Product List ---
            else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp) // Add padding at bottom to avoid FAB overlap
                ) {
                    // Use product ID as the key for efficient updates/animations
                    items(items = sortedProducts, key = { product -> product.id }) { product ->

                        // TODO: Get multiplier summary string for this product
                        val assignments = productAssignments[product.id] // Get Map<MultId, Override?>
                        val summary = assignments?.keys?.mapNotNull { multId ->
                            currentCatalog?.multipliers?.find { it.id == multId }?.name // Find names
                        }?.joinToString(", ") // Join names

                        ProductRow(
                            product = product,
                            quantity = quantities[product.id] ?: "", // Provide quantity string or empty
                            assignedMultiplierSummary = summary, // Pass the summary string
                            onQuantityChange = { newQuantity ->
                                viewModel.updateQuantity(product.id, newQuantity)
                            },
                            onAssignMultiplierClick = { prod -> // Renamed lambda param
                                focusManager.clearFocus()
                                viewModel.showDialog(DialogState.ASSIGN_MULTIPLIER, prod)
                            },
                            onRowClick = { prod -> // Renamed lambda param
                                focusManager.clearFocus()
                                viewModel.showDialog(DialogState.ADD_EDIT_PRODUCT, prod) // Open edit dialog
                            }
                        )
                    }
                } // End of LazyColumn
            } // End of else (list display)
        } // End of Column (main content area)
    } // End of Scaffold
}