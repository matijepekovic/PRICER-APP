package com.example.pricer.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Functions // Example icon for "assign functions/multipliers"
import androidx.compose.material3.*
import androidx.compose.runtime.* // Needed for basic compose state functions if used internally
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.pricer.data.model.Product
import com.example.pricer.util.formatCurrency // Import the formatting util

/**
 * A Composable function that displays a single row for a Product in the catalog list.
 * It includes product details, a quantity input field, and interaction buttons.
 *
 * @param product The data object for the product to display.
 * @param quantity The current quantity entered for this product (as a String for TextField).
 * @param assignedMultiplierSummary A string summarizing assigned multipliers (e.g., "Discount, Surcharge"). Null or empty if none.
 * @param onQuantityChange Callback invoked when the quantity input value changes. Passes the new String value.
 * @param onAssignMultiplierClick Callback invoked when the assign multiplier button is clicked. Passes the product.
 * @param onRowClick Callback invoked when the main body of the row is clicked. Typically used to edit the product. Passes the product.
 * @param modifier Optional Modifier for customizing the row container.
 */
@OptIn(ExperimentalMaterial3Api::class) // For OutlinedTextField, Card potentially
@Composable
fun ProductRow(
    product: Product,
    quantity: String, // Use String for TextField compatibility
    assignedMultiplierSummary: String?, // TODO: Populate this based on ViewModel state later
    onQuantityChange: (String) -> Unit,
    onAssignMultiplierClick: (Product) -> Unit,
    onRowClick: (Product) -> Unit, // For editing
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 8.dp)
            // Make the whole card clickable for editing the product
            .clickable { onRowClick(product) },
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp), // Subtle elevation
        shape = MaterialTheme.shapes.medium // Use standard shape
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp), // Adjust padding
            verticalAlignment = Alignment.CenterVertically // Align items vertically in the row
        ) {
            // --- Product Details Column (Takes most space) ---
            Column(
                modifier = Modifier
                    .weight(1f) // Allows this column to grow and shrink
                    .padding(end = 8.dp) // Space before quantity field
            ) {
                // Product Name (Bold)
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium, // Good size for item titles
                    fontWeight = FontWeight.SemiBold, // Make it stand out
                    maxLines = 2, // Allow wrapping slightly
                    overflow = TextOverflow.Ellipsis // Add ellipsis if name is too long
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Description (Smaller text, optional)
                if (product.description.isNotBlank()) {
                    Text(
                        text = product.description,
                        style = MaterialTheme.typography.bodySmall, // Smaller font for description
                        color = MaterialTheme.colorScheme.onSurfaceVariant, // Slightly muted color
                        maxLines = 3, // Allow a few lines
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Price and Unit Type
                Text(
                    text = "${formatCurrency(product.basePrice)} / ${product.unitType}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Normal // Regular weight for price info
                )

                // --- TODO: Placeholder for Assigned Multipliers Summary ---
                if (!assignedMultiplierSummary.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Modifiers: $assignedMultiplierSummary",
                        style = MaterialTheme.typography.labelSmall, // Use label style
                        color = MaterialTheme.colorScheme.primary, // Highlight with primary color?
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                // --- End of Placeholder ---
            }

            // --- Quantity Input Field ---
            OutlinedTextField(
                value = quantity,
                onValueChange = { newValue ->
                    // Allow only digits (and empty string for clearing)
                    if (newValue.all { it.isDigit() }) {
                        onQuantityChange(newValue)
                    }
                },
                label = { Text("Qty") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number // Use number keyboard
                ),
                modifier = Modifier
                    .width(90.dp) // Fixed width for consistency
                    .padding(end = 4.dp), // Space before icon button
                singleLine = true, // Prevent multi-line input
                textStyle = LocalTextStyle.current.copy( // Ensure text aligns well if needed
                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                ),
                // Condense padding if needed for space
                // contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            )

            // --- Assign Multiplier Button ---
            IconButton(
                onClick = { onAssignMultiplierClick(product) },
                modifier = Modifier.align(Alignment.CenterVertically) // Ensure icon is centered in row height
            ) {
                Icon(
                    // Choose an appropriate icon (Functions, Tune, Settings, PriceCheck?)
                    imageVector = Icons.Filled.Functions,
                    contentDescription = "Assign Multipliers to ${product.name}", // Accessibility
                    tint = MaterialTheme.colorScheme.primary // Use primary color for emphasis?
                )
            }
        }
    }
}