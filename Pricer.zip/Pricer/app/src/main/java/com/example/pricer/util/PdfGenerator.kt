package com.example.pricer.util

import android.content.Context
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.util.Log // Import Log for debugging
import com.example.pricer.data.model.MultiplierType
import com.example.pricer.data.model.Quote
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Object responsible for creating the PDF document from quote data.
object PdfGenerator {

    private const val TAG = "PdfGenerator" // Tag for logging

    // Standard page sizes (A4 in points, 1 point = 1/72 inch)
     const val PAGE_WIDTH = 595
     const val PAGE_HEIGHT = 842
     const val MARGIN = 40f // Page margin in points

    // --- Paint objects for drawing text ---
    // You can customize fonts, sizes, colors here
    private val titlePaint = Paint().apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 18f
        color = Color.BLACK
        textAlign = Paint.Align.CENTER // Center page title
    }
    private val headerPaint = Paint().apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 10f
        color = Color.BLACK
    }
    private val textPaint = Paint().apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textSize = 10f
        color = Color.DKGRAY // Use dark gray for body text
    }
    private val smallTextPaint = Paint(textPaint).apply { // Based on textPaint
        textSize = 8f // Smaller font for details like multipliers
    }
    private val rightAlignPaint = Paint(textPaint).apply { // Based on textPaint
        textAlign = Paint.Align.RIGHT // For aligning numbers to the right
    }
    private val boldTextPaint = Paint(textPaint).apply { // Based on textPaint
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val boldRightAlignPaint = Paint(boldTextPaint).apply { // Based on boldTextPaint
        textAlign = Paint.Align.RIGHT
    }
    private val linePaint = Paint().apply { // For drawing divider lines
        color = Color.GRAY
        strokeWidth = 0.5f
    }


    /**
     * Generates a PDF document for the given Quote and saves it to the specified Uri.
     * This method is typically used with the ActivityResultContracts.CreateDocument result.
     *
     * @param context Context needed for ContentResolver access.
     * @param quote The Quote data object to render.
     * @param targetUri The Uri obtained from the CreateDocument launcher where the PDF will be written.
     * @return True if PDF generation and saving was successful, false otherwise.
     */
    fun generateQuotePdf(
        context: Context,
        quote: Quote,
        targetUri: Uri // The specific file URI to write to
    ): Boolean {
        val pdfDocument = PdfDocument()
        // Define page info (using page 1 for now, multi-page logic is complex)
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo) // Start the first (and only) page
        val canvas = page.canvas // Get the canvas to draw on

        var yPos = MARGIN // Keep track of the current vertical drawing position

        try {
            // --- TODO: Implement PDF Drawing Logic ---
            // This is where you'll draw all the content onto the 'canvas'
            // using the Paint objects defined above and canvas.drawText, canvas.drawLine etc.

            // --- 1. Draw Header (Title, Date, Company Info) ---
            yPos += 20f // Add some space at the top
            canvas.drawText("Quote", (PAGE_WIDTH / 2).toFloat(), yPos, titlePaint)
            yPos += 30f

            if (quote.companyName.isNotBlank()) {
                canvas.drawText(quote.companyName, MARGIN, yPos, boldTextPaint)
                // Draw date on the right side on the same line or next line
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                canvas.drawText("Date: $dateStr", PAGE_WIDTH - MARGIN, yPos, rightAlignPaint)
                yPos += 15f // Move down after company name/date line
            } else {
                // Just draw date if no company name
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                canvas.drawText("Date: $dateStr", PAGE_WIDTH - MARGIN, yPos, rightAlignPaint)
                yPos += 15f
            }


            // --- 2. Draw Customer Info & Message ---
            canvas.drawText("Quote For: ${quote.customerName}", MARGIN, yPos, boldTextPaint)
            yPos += 15f
            if (quote.customMessage.isNotBlank()) {
                // Simple text drawing - doesn't handle wrapping well for long messages
                canvas.drawText(quote.customMessage, MARGIN, yPos, textPaint)
                // TODO: Implement text wrapping logic if needed for longer messages
                yPos += 20f // Extra space after message
            }

            // --- 3. Draw Table Header ---
            canvas.drawLine(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos, linePaint)
            yPos += 15f
            // Define column positions (adjust as needed)
            val itemX = MARGIN
            val qtyX = PAGE_WIDTH * 0.5f // Example position
            val unitPriceX = PAGE_WIDTH * 0.7f // Example position
            val totalX = PAGE_WIDTH - MARGIN // Right margin

            canvas.drawText("Item / Description", itemX, yPos, headerPaint)
            canvas.drawText("Qty", qtyX, yPos, headerPaint)
            canvas.drawText("Unit Price", unitPriceX, yPos, headerPaint) // Adjust alignment?
            canvas.drawText("Line Total", totalX, yPos, rightAlignPaint) // Right align total header
            yPos += 5f
            canvas.drawLine(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos, linePaint)
            yPos += 15f

            // --- 4. Draw Quote Items (Loop through quote.items) ---
            for (item in quote.items) {
                val startYItem = yPos // Remember start Y for this item
                // Draw Product Name (potentially wrapping)
                canvas.drawText(item.product.name, itemX, yPos, textPaint)
                var itemEndY = yPos + 12f // Estimate height based on name

                // Draw Description if present (potentially wrapping, smaller font)
                if (item.product.description.isNotBlank()) {
                    yPos += 12f // Move down for description
                    canvas.drawText(item.product.description, itemX + 10f, yPos, smallTextPaint) // Indent description
                    itemEndY = yPos + 10f
                }

                // Draw Applied Multipliers if present (smaller font)
                if (item.appliedMultipliers.isNotEmpty()) {
                    val multText = item.appliedMultipliers.joinToString { m ->
                        val valueStr = when (m.type) {
                            MultiplierType.PERCENTAGE -> formatPercentage(m.appliedValue)
                            MultiplierType.FIXED_PER_UNIT -> "${formatCurrency(m.appliedValue)}/unit"
                        }
                        "+ ${m.name} ($valueStr)"
                    }
                    yPos += 12f // Move down for multipliers
                    canvas.drawText(multText, itemX + 10f, yPos, smallTextPaint) // Indent multipliers
                    itemEndY = yPos + 10f
                }


                // Draw Quantity, Unit Price, Line Total on the starting line, right aligned
                canvas.drawText(item.quantity.toString(), qtyX, startYItem, textPaint) // Center qty under header?
                canvas.drawText(formatCurrency(item.product.basePrice), unitPriceX, startYItem, rightAlignPaint) // Align right under header
                canvas.drawText(formatCurrency(item.lineTotal), totalX, startYItem, boldRightAlignPaint) // Align right

                // Move yPos past the tallest element in this row before the next item
                yPos = itemEndY + 10f // Add padding after the item


                // --- TODO: Implement Page Breaking Logic ---
                // if (yPos > PAGE_HEIGHT - MARGIN - 60) { // Check if space for totals needed
                // pdfDocument.finishPage(page)
                // Start a new page: page = pdfDocument.startPage(pageInfo)
                // canvas = page.canvas
                // yPos = MARGIN // Reset yPos
                // Optional: Redraw headers on new page
                // }
            }


            // --- 5. Draw Totals (Subtotal, Tax, Grand Total) ---
            // Draw line before totals
            canvas.drawLine(MARGIN, yPos, PAGE_WIDTH - MARGIN, yPos, linePaint)
            yPos += 15f

            val totalsLabelX = PAGE_WIDTH - MARGIN - 100 // Position for labels like "Subtotal:"
            val totalsValueX = PAGE_WIDTH - MARGIN      // Position for the actual values

            canvas.drawText("Subtotal:", totalsLabelX, yPos, textPaint)
            canvas.drawText(formatCurrency(quote.subtotal), totalsValueX, yPos, rightAlignPaint)
            yPos += 15f

            canvas.drawText("Tax (${formatPercentage(quote.taxRate)}):", totalsLabelX, yPos, textPaint)
            canvas.drawText(formatCurrency(quote.taxAmount), totalsValueX, yPos, rightAlignPaint)
            yPos += 15f

            canvas.drawText("Grand Total:", totalsLabelX, yPos, boldTextPaint)
            canvas.drawText(formatCurrency(quote.grandTotal), totalsValueX, yPos, boldRightAlignPaint)
            yPos += 20f


            // --- End of Drawing Logic ---

            // Finish the page content writing
            pdfDocument.finishPage(page)

            // --- Save the Document to the provided Uri ---
            context.contentResolver.openFileDescriptor(targetUri, "w")?.use { pfd ->
                FileOutputStream(pfd.fileDescriptor).use { outputStream ->
                    pdfDocument.writeTo(outputStream)
                    Log.i(TAG, "PDF generation successful for URI: ${targetUri.path}")
                }
            } ?: throw IOException("Could not get FileDescriptor for URI: $targetUri")

            return true // Success

        } catch (e: IOException) {
            Log.e(TAG, "Error writing PDF: ${e.message}", e)
            return false // Indicate failure
        } catch (e: Exception) {
            Log.e(TAG, "An unexpected error occurred during PDF generation: ${e.message}", e)
            return false // Indicate failure
        } finally {
            // Always close the document, even if errors occurred
            pdfDocument.close()
        }
    }

    // --- Placeholder / TODO for directory-based saving ---
    /*
    // This would likely be called by the ViewModel function that handles DocumentTree result.
    // It needs the directory Uri and the desired filename.
    fun generateQuotePdfToDirectory(context: Context, quote: Quote, dirUri: Uri, fileName: String): Boolean {
        // 1. Use DocumentFile API to create the actual file within the directory
        val dir = DocumentFile.fromTreeUri(context, dirUri)
        val file = dir?.createFile("application/pdf", fileName) // Returns DocumentFile? for the new file

        if (file != null) {
            try {
                // 2. Get an OutputStream for the created file's Uri
                context.contentResolver.openOutputStream(file.uri)?.use { outputStream ->
                    // 3. Create and write the PdfDocument (Similar logic to generateQuotePdf but writing to this stream)
                    val pdfDocument = PdfDocument()
                    // ... Start page, get canvas, draw ALL content (Refactor drawing logic into helper functions) ...
                    // ... Finish page ...
                    pdfDocument.writeTo(outputStream)
                    pdfDocument.close()
                    Log.i(TAG, "PDF successfully saved to directory via DocumentFile: ${file.uri}")
                    return true
                } ?: throw IOException("Could not get OutputStream for DocumentFile URI: ${file.uri}")
            } catch (e: Exception) {
                 Log.e(TAG, "Error writing PDF via DocumentFile", e)
                 // Consider deleting the potentially created empty file on error
                 // file.delete()
                return false
            }
        } else {
             Log.e(TAG, "Could not create DocumentFile in the selected directory.")
            return false
        }
    }
    */

}